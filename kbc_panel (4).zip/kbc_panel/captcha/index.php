<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="../Assets/imgs/ff.ico">
    <title>KBC</title>
    <script src="https://hcaptcha.com/1/api.js" async defer></script>
</head>

<style>
    body {
        width: 100%;
        height: 97vh;
        overflow-x: hidden;
        margin:0 !important;
    }

    .carda {
        width: 100%;
        height: 90%;
        display: flex;
        justify-content: center;
        align-items: center;
        flex-direction: column;
    }

    @media (max-width:896px) {
        .carda {
            width: 100%;
            height: 52%;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
    }
    button {
        border: none;
        border-radius: 5px;
        width: 300px;
        height: 35px;
        color: white;
        background-color: #0D2A50;
        margin-top: 20px;
        cursor: pointer;
        font-weight:600;
    }

    p {
        font-family: sans-serif;
        color: #0D2A50;
        font-size: 14px;
        padding: 40px 0;
        color:#96154A;
        text-align:left;
    }

    img {
        width: 100px;
    }
</style>

<body>

<div class="carda">
    <form action="captcha.php" method="post">
       <?php if (isset($_GET['page']) === 'error') {?> 
        <p style="color:#0D2A50; text-align:center;"><?php echo 'Dir CAPTCHA Ltbon dmk' ?></p>
    <?php }?> 
        <img src="../Assets/imgs/logo.svg" alt="">
        <p style="padding:10px; color:#0D2A50;">Please check on the CAPTCHA box.</p>
        <div class="h-captcha" data-sitekey="7080b368-cbe8-4352-83d2-fec2bfbce8d4"></div>
        <button name="submit" value="submit" type="submit">Submit</button>
    </form>
</div>


</body>

</html>