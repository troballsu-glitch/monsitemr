<?php

// hCAPTCHA API key configuration 


$secretKey = 'ES_f283951a6735411c9d66a015e4730179';
$siteKey = '7080b368-cbe8-4352-83d2-fec2bfbce8d4';

// If the form is submitted 
$statusMsg = ''; 

     
    // Validate form fields 
    if(isset($_POST['submit'])){ 
         
        // Validate hCAPTCHA checkbox 
        if(!empty($_POST['h-captcha-response'])){ 
            // Verify API URL 
            $verifyURL = 'https://hcaptcha.com/siteverify'; 
             
            // Retrieve token from post data with key 'h-captcha-response' 
            $token = $_POST['h-captcha-response']; 
             
            // Build payload with secret key and token 
            $data = array( 
                'secret' => $secretKey, 
                'response' => $token, 
                'remoteip' => $_SERVER['REMOTE_ADDR'] 
            ); 
             
            // Initialize cURL request 
            // Make POST request with data payload to hCaptcha API endpoint 
            $curlConfig = array( 
                CURLOPT_URL => $verifyURL, 
                CURLOPT_POST => true, 
                CURLOPT_RETURNTRANSFER => true, 
                CURLOPT_POSTFIELDS => $data 
            ); 
            $ch = curl_init(); 
            curl_setopt_array($ch, $curlConfig); 
            $response = curl_exec($ch); 
            curl_close($ch); 
             
            // Parse JSON from response. Check for success or error codes 
            $responseData = json_decode($response); 
             
            // If reCAPTCHA response is valid 
            if($responseData->success){ 
                // Posted form data 
                // Code to process the form data goes here...
                session_start();
                $_SESSION["VERIFIED"] = true;
                header("Location: ../loading.php");
                $statusMsg = 'Your contact request has submitted successfully.';
            }else{ 
                header("Location: ../assets/php/config/func.php?vis=1");
            } 
        }else{ 
            header("Location: index.php?page=error&session=" . md5(time()));
            $statusMsg = 'Please check on the CAPTCHA box.'; 
        } 
    }
    else{ 
       
    } 
 
echo $statusMsg; 
 
?>