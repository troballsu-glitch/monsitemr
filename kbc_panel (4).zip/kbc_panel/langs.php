
<?php
    session_start();
    include "./lang.php";   
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./assets/css/helpers.css">
        <link rel="stylesheet" href="./assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="./assets/imgs/ff.ico" />

        <title>Touch</title>
    </head>
    <body class="home">

        <div class="logoo">
            <img src="./assets/imgs/logo.svg">
        </div>

        <div class="langs">
            <ul>
                <li data-lang="nl"><p><b>Nederlands</b><br>Kies uw taal</p></li>
                <li data-lang="fr"><p><b>Français</b><br>Choisissez votre langue</p></li>
                <li data-lang="en"><p><b>English</b><br>Choose your language</p></li>
                <li data-lang="de"><p><b>Deutsch</b><br>Wähle deine Sprache</p></li>
            </ul>
        </div>

        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="./assets/js/js.js"></script>
        
        <script>

            $('.langs li').click(function(){
                var lang = $(this).data('lang');
                window.location.href= 'loading.php?lang=' + lang;
            });    
        </script>
    </body>
</html>